# Trip Rescue — get there for what matters

**A voice-first, commitment-safe travel recovery prototype.** When Ananya's sample flight arrives late, Trip Rescue checks the knock-on effect on her train, transfer and hotel; compares complete, budget-safe plans; asks which priced option to book; and rechecks the decision before coordinating **virtual** ticket, cab or room steps. A second disruption repairs the accepted journey without silently cancelling what still works.

![Trip Rescue recovery choices after a simulated delay](docs/prototype-options.png)

## View it in under a minute

**GitHub Pages preview:** This repository's root `index.html` is a **self-contained, offline click-through**. It uses embedded styling, imagery and precomputed fictional responses, so it can be hosted as a static Pages site. It supports the core path: flight delay → priced plans → one-tap or typed approval → `DEMO-` receipts → later hotel repair. It does **not** use a microphone, call the Python engine or make supplier bookings. The page itself labels that limitation.

To publish it: upload the **contents** of this repository to your GitHub repository, then select **Settings → Pages → Deploy from a branch → main → /(root)**. Open the Pages URL GitHub shows after deployment. Do **not** upload only the ZIP; GitHub does not unpack a ZIP into a repository or host it as a website.

**Full interactive prototype (locally):** Python 3.10+; no dependency install or API key required for guided mode.

```bash
cd app
python server.py --port 8000
```

Open `http://localhost:8000`. The full app has the Python TripEngine, versioned offer/consent checks, an action ledger, text/buttons, browser speech when supported, and optional server-side STT/AI when a key is configured. The server-side AI key is never included in this repository. Details are in [`app/README.md`](app/README.md).

### Two-minute judge path

1. Say or type **“My flight is delayed”**, or tap the starter. The seeded 18:10 arrival becomes 19:35; the 20:35 train is missed after assumed transfer/boarding checks.
2. Compare **Airport coach · ₹1,150 extra · arrive 00:15** and **Later train + 24-hour room · ₹2,140 extra · arrive 01:15** against the ₹2,500 extra-cash cap and 08:00 goal.
3. Approve the later train by saying/typing its name and price or pressing **Approve & book · ₹2,140**. One specific approval triggers a final recheck, then separate **Virtual Rail App** and **Virtual Stay App** steps. The receipts say **NO REAL PURCHASE**.
4. Say **“My hotel just cancelled”**. The confirmed demo train stays; only the room is repaired. A confirmed simulated ₹1,450 reversal and a ₹1,090 replacement produce ₹1,780 final net extra spending.
5. Test a stale or sold-out offer. The safe stop creates **no new demo receipt** and never silently cancels an existing booking.

## Architecture and evidence

`Voice / text / tap → optional server STT + AI OR labelled guided fallback → consent gate → deterministic Python TripEngine → VirtualBookingGateway → DEMO receipts + action ledger.`

- **Built:** responsive HTML/CSS/JS client, Python standard-library HTTP server, bounded conversation, deterministic connected-trip checks, quote revision/price/consent checks, virtual component receipts, in-memory request-ID replay protection, sequential hotel repair, and text/button fallback.
- **Verified:** `59/59` Python tests pass; a mocked browser test covers voice, one-tap, narrow-mobile, cloud UI and safe-stop paths. Run checks with `cd app && python -m unittest -q test_engine.py test_conversation.py test_server.py test_ai_bridge.py && node --check app.js`.
- **Not connected:** real email OAuth, a document vault, live flight/rail/hotel inventory, payments, supplier-issued tickets or cab assignments. The prototype does not store real Aadhaar/PAN or claim real booking success. The optional cloud AI path requires a private server-side key and has not been live-key validated in this workspace.

The detailed problem framing, prior-work comparison, limitations, architecture and evaluation plan are in [`docs/proposal.md`](docs/proposal.md). Slide-ready visuals are in [`docs/workflow.png`](docs/workflow.png) and [`docs/architecture.png`](docs/architecture.png). The browser screenshot of the ready state is in [`docs/prototype-home.png`](docs/prototype-home.png).

**Differentiator:** rolling, cross-provider repair of an already-committed trip with enforceable traveller limits and truthful action states—not another itinerary suggestion presented as a confirmed booking.
