"""Zero-dependency HTTP server for the fictional Trip Rescue interactive demo."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import ai_bridge
from booking_apps import VirtualBookingGateway
from conversation import ConversationMemory, booking_reply, explicit_plan_consent, present_context, redact, respond
from engine import TripEngine, TripError

ROOT = Path(__file__).resolve().parent
SESSIONS: dict[str, TripEngine] = {}
MEMORIES: dict[str, ConversationMemory] = {}
BOOK_REQUESTS: dict[str, dict[str, dict]] = {}  # Bounded, in-memory retry ledger; demo only.
GATEWAY = VirtualBookingGateway()
LOCK = threading.RLock()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _session(self) -> tuple[str, TripEngine, ConversationMemory]:
        token = self.headers.get("X-Trip-Session", "demo")
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,80}", token):
            token = "demo"
        with LOCK:
            if token not in SESSIONS:
                SESSIONS[token] = TripEngine()
                MEMORIES[token] = ConversationMemory()
            return token, SESSIONS[token], MEMORIES[token]

    def _json(self, data: dict, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/capabilities":
            self._json({"ai_enabled": ai_bridge.enabled(), "mode": "ai" if ai_bridge.enabled() else "guided",
                        "notice": "Cloud transcription and conversation" if ai_bridge.enabled() else "Guided demo; add a server-side AI key for cloud transcription and more open conversation."})
            return
        if path == "/api/state":
            _, engine, memory = self._session()
            with LOCK:
                state = engine.snapshot()
                memory.show_offers(state)  # The response displays these prices in plan cards.
                self._json({"state": state, "conversation": present_context(engine, memory)})
            return
        if path.startswith("/api/"):
            self._json({"error": "Unknown demo endpoint."}, 404)
            return
        # Never publish server code, tests or configuration through the static server.
        if path not in {"/", "/index.html", "/styles.css", "/app.js", "/favicon.svg", "/public/journey-hero.webp"}:
            self.send_error(404, "Not found")
            return
        return super().do_GET()

    def _handle_turn(self, token: str, text: str, transcript: bool = False) -> None:
        """Call the optional model outside the engine lock, then revalidate state."""
        if not isinstance(text, str) or not text.strip() or len(text) > 500:
            self._json({"error": "Please say or type a short request."}, 400)
            return
        with LOCK:
            engine = SESSIONS[token]
            memory = MEMORIES[token]
            before = engine.snapshot()
            revision = engine.revision
            sequence = memory.sequence
            context = memory.context()
        decision = None
        mode = "guided"
        notice = ""
        if ai_bridge.enabled():
            try:
                decision = ai_bridge.interpret(redact(text), before, context)
                mode = "ai"
            except ai_bridge.AIUnavailable:
                notice = "AI conversation was unavailable; guided fallback answered this turn."
        with LOCK:
            current = SESSIONS[token]
            current_memory = MEMORIES[token]
            if (current is not engine or current.revision != revision
                    or current_memory is not memory or current_memory.sequence != sequence):
                state = current.snapshot()
                self._json({"reply": "Another turn or trip update arrived while I was checking. I didn't apply the older request. What do you need now?",
                            "state": state, **present_context(current, current_memory), "mode": mode,
                            "transcript": redact(text) if transcript else None, "notice": notice})
                return
            result = respond(current, memory, text, decision, mode)
        if transcript:
            result["transcript"] = redact(text)
        if notice:
            result["notice"] = notice
        self._json(result)

    def _conversation(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = 0
        if length < 0 or length > 8000:
            self._json({"error": "Request is too large."}, 413)
            return
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("Expected an object")
        except (ValueError, json.JSONDecodeError):
            self._json({"error": "Invalid JSON body."}, 400)
            return
        token, _, _ = self._session()
        self._handle_turn(token, payload.get("text"))

    def _voice(self) -> None:
        if not ai_bridge.enabled():
            self._json({"error": "Cloud voice needs a server-side API key. Use browser speech or text in this demo."}, 503)
            return
        media_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        if media_type not in ai_bridge.ALLOWED_AUDIO:
            self._json({"error": "Unsupported recording format. Try typing your request."}, 415)
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = 0
        if length < 100 or length > 2_000_000:
            self._json({"error": "Recording too short or too large. Try a brief request."}, 413)
            return
        audio = self.rfile.read(length)
        try:
            text = ai_bridge.transcribe(audio, media_type)
        except ValueError as exc:
            self._json({"error": str(exc)}, 400)
            return
        except ai_bridge.AIUnavailable:
            self._json({"error": "Voice transcription is temporarily unavailable. Please type or try browser speech."}, 502)
            return
        token, _, _ = self._session()
        self._handle_turn(token, text, transcript=True)

    def _book(self, token: str, engine: TripEngine, memory: ConversationMemory, payload: dict) -> None:
        """One explicit click, then all required *virtual* supplier steps. Called under LOCK."""
        request_id = payload.get("request_id")
        plan_id = payload.get("plan_id")
        revision = payload.get("revision")
        price = payload.get("price")
        consent = payload.get("consent")
        if not isinstance(request_id, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{12,80}", request_id):
            raise TripError("A unique booking request ID is required.")
        if (not isinstance(plan_id, str) or type(revision) is not int or type(price) is not int
                or not isinstance(consent, str) or len(consent) > 160):
            raise TripError("A plan, exact quoted price, revision and explicit approval are required.")
        fingerprint = (plan_id, revision, price, hashlib.sha256(consent.encode("utf-8")).hexdigest())
        records = BOOK_REQUESTS.setdefault(token, {})
        previous = records.get(request_id)
        if previous:
            if previous["fingerprint"] != fingerprint:
                raise TripError("That booking request ID was already used for a different choice. Nothing changed.", 409)
            state = engine.snapshot()
            unchanged = previous["trip_id"] == engine.trip_id and previous["phase"] == state["phase"]
            reply = ("This same virtual booking request was already handled; it was not sent twice. " + previous["reply"]
                     if unchanged and previous["status"] == 200 else
                     "That request was already handled on an earlier trip state. Nothing was repeated; check the current journey."
                     if previous["status"] == 200 else previous["error"])
            body = {"state": state, **present_context(engine, memory), "reply": reply, "replayed": True,
                    "booking": previous.get("booking") if unchanged else None}
            if previous["status"] != 200:
                body["error"] = previous["error"]
            self._json(body, previous["status"])
            return
        if len(records) >= 64:
            raise TripError("Too many demo booking requests in this session. Start a new session; nothing changed.", 429)
        current = engine.snapshot()
        plan = next((p for p in current["plans"] if p["id"] == plan_id), None)
        if (not plan or not memory.offer_matches(current, plan)
                or revision != current["revision"] or price != plan["price"]):
            raise TripError("That offer or price has changed. Review the current choices; nothing was booked.", 409)
        if not explicit_plan_consent(consent, plan):
            raise TripError("Approve the selected option by name or exact price first. Nothing was booked.", 409)
        try:
            _, receipt = GATEWAY.book(engine, plan_id, revision, price)
            memory.pending = None
            memory.last_plan = plan_id
            memory.sequence += 1  # Invalidate an older, concurrent AI turn.
            reply = booking_reply(receipt)
            outcome = {"fingerprint": fingerprint, "status": 200, "trip_id": engine.trip_id,
                       "phase": engine.phase, "reply": reply, "booking": receipt}
            records[request_id] = outcome
            state = engine.snapshot()
            memory.show_offers(state)
            self._json({"reply": reply, "booking": receipt, "replayed": False, "state": state,
                        **present_context(engine, memory)})
        except TripError as exc:
            memory.pending = None
            memory.sequence += 1
            records[request_id] = {"fingerprint": fingerprint, "status": exc.code,
                                   "trip_id": engine.trip_id, "phase": engine.phase,
                                   "error": str(exc), "reply": str(exc)}
            state = engine.snapshot()
            memory.show_offers(state)
            self._json({"error": str(exc), "reply": str(exc), "booking": None, "state": state,
                        **present_context(engine, memory)}, exc.code)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/conversation":
            self._conversation()
            return
        if path == "/api/voice":
            self._voice()
            return
        if not path.startswith("/api/"):
            self._json({"error": "Not found."}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = 0
        if length < 0 or length > 8000:
            self._json({"error": "Request is too large."}, 413)
            return
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("Expected object")
        except (ValueError, json.JSONDecodeError):
            self._json({"error": "Invalid JSON body."}, 400)
            return
        token, engine, memory = self._session()
        with LOCK:
            try:
                if path == "/api/book":
                    self._book(token, engine, memory, payload)
                    return
                message = None
                booking = None
                if path == "/api/reset":
                    engine = TripEngine()
                    SESSIONS[token] = engine
                    memory.reset()
                    message = "The demo was reset."
                elif path == "/api/preferences":
                    engine.set_preferences(payload)
                    message = "Preferences updated. Every option has been checked again."
                elif path == "/api/disrupt/flight":
                    engine.disrupt_flight()
                    message = "Flight delay replayed. Downstream bookings checked."
                elif path == "/api/disrupt/hotel":
                    engine.disrupt_hotel()
                    message = "Hotel cancellation replayed. The confirmed travel leg was preserved."
                elif path == "/api/offer/sellout":
                    engine.mark_offer_sold_out(str(payload.get("plan_id", "")))
                    message = "Offer changed in the simulator. Revalidation is now required."
                elif path == "/api/approve":
                    # The legacy JSON action must obey the same reviewed-quote and
                    # plan-specific consent boundary as conversational approval.
                    plan_id = str(payload.get("plan_id", ""))
                    quote = present_context(engine, memory)["pending"]
                    plan = next((p for p in engine.snapshot()["plans"] if p["id"] == plan_id), None)
                    consent = payload.get("consent", "")
                    if (not quote or quote["kind"] != "plan" or quote["plan_id"] != plan_id
                            or quote["revision"] != payload.get("revision") or not plan
                            or not isinstance(consent, str) or not explicit_plan_consent(consent, plan)):
                        raise TripError("Review the current plan and explicitly confirm its name or price first. Nothing changed.", 409)
                    memory.pending = None
                    memory.sequence += 1
                    message, booking = GATEWAY.book(engine, plan_id, payload.get("revision"), quote["price"])
                else:
                    self._json({"error": "Unknown demo endpoint."}, 404)
                    return
                state = engine.snapshot()
                memory.show_offers(state)
                self._json({"message": message, "booking": booking, "state": state,
                            "conversation": present_context(engine, memory)})
            except TripError as exc:
                state = engine.snapshot()
                memory.show_offers(state)
                self._json({"error": str(exc), "state": state,
                            "conversation": present_context(engine, memory)}, exc.code)

    def end_headers(self) -> None:
        if self.path.endswith((".html", ".js", ".mjs", ".css")):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, format, *args) -> None:
        # Standard HTTP line logs only; never log raw audio or transcripts.
        print(f"[{self.log_date_time_string()}] {format % args}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    print(f"Trip Rescue demo ready on http://0.0.0.0:{args.port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
