"""Stateful, bounded conversation around the deterministic TripEngine.

A cloud model may interpret language, but only allowlisted operations below can
change the demo. Every simulated approval is matched against a staged quote and
requires explicit, plan-specific consent; the engine rechecks feasibility.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any

from booking_apps import VirtualBookingGateway
from engine import TripEngine, TripError

GATEWAY = VirtualBookingGateway()


@dataclass
class ConversationMemory:
    pending: dict[str, Any] | None = None
    last_plan: str | None = None
    offered: dict[str, Any] | None = None  # Prices and revision actually shown to this traveller.
    history: list[dict[str, str]] = field(default_factory=list)
    sequence: int = 0  # An older in-flight model turn must not consume a newer review.

    def reset(self) -> None:
        self.pending = None
        self.last_plan = None
        self.offered = None
        self.history.clear()
        self.sequence += 1

    def show_offers(self, state: dict[str, Any]) -> None:
        if state["phase"] in ("flight_alert", "hotel_alert"):
            self.offered = {"revision": state["revision"],
                            "prices": {p["id"]: p["price"] for p in state["plans"]}}
        else:
            self.offered = None

    def offer_matches(self, state: dict[str, Any], plan: dict[str, Any]) -> bool:
        return bool(self.offered and self.offered["revision"] == state["revision"]
                    and self.offered["prices"].get(plan["id"]) == plan["price"])

    def context(self) -> dict[str, Any]:
        return {"pending": self.pending, "last_plan": self.last_plan, "history": self.history[-4:]}

    def remember(self, question: str, answer: str) -> None:
        self.history.append({"user": question[:300], "assistant": answer[:450]})
        self.history = self.history[-4:]
        self.sequence += 1


def redact(text: str) -> str:
    """Do not retain common identifier patterns in conversational memory."""
    value = str(text or "").strip()[:500]
    value = re.sub(r"[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}", "[email redacted]", value)
    value = re.sub(r"(?<!\w)[A-Z]{5}\d{4}[A-Z](?!\w)", "[PAN redacted]", value, flags=re.I)
    value = re.sub(r"(?<!\w)(?:\d[ -]?){8,}(?!\w)", "[number redacted]", value)
    return value


def norm(text: str) -> str:
    value = unicodedata.normalize("NFKD", text).lower().replace("’", "'")
    value = re.sub(r"\b(let|what)'s\b", r"\1s", value)
    value = re.sub(r"(?<=[a-z])'(?=s\b)", " ", value)  # flight's → flight s
    value = re.sub(r"(?<=[a-z])'(?=[a-z])", "", value)  # don't → dont; can't → cant
    value = re.sub(r"(?<=\d),(?=\d)", "", value)
    value = re.sub(r"[^a-z0-9₹ ]", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def money(amount: int) -> str:
    return f"₹{amount:,}"


def available(state: dict[str, Any], plan_id: str | None) -> dict[str, Any] | None:
    return next((p for p in state["plans"] if p["id"] == plan_id), None)


def plan_reference(text: str, state: dict[str, Any], memory: ConversationMemory) -> str | None:
    value = norm(text)
    matches = [
        ("royal-fern", r"\b(royal|fern)\b"),
        ("blue-lotus", r"\b(blue lotus|lotus)\b"),
        ("coach", r"\b(coach|bus)\b"),
        ("rail", r"\b(later train|new train|rail|railway)\b"),
        ("car", r"\b(taxi|private car|cab)\b"),
    ]
    for plan_id, pattern in matches:
        if re.search(pattern, value) and available(state, plan_id):
            return plan_id
    if "original train" not in value and re.search(r"\btrain\b", value) and available(state, "rail"):
        return "rail"
    plans = state["plans"]
    if not plans:
        return None
    spoken_prices = [p for p in plans if re.search(rf"(?<!\d){p['price']}(?!\d)", value)]
    if len(spoken_prices) == 1:
        return spoken_prices[0]["id"]
    if re.search(r"\b(second|other one|option two|option 2)\b", value) and len(plans) > 1:
        return plans[1]["id"]
    if re.search(r"\b(first|best|recommended|option one|option 1)\b", value):
        return plans[0]["id"]
    if re.search(r"\b(cheapest|least expensive|lowest priced|least cost)\b", value):
        return min(plans, key=lambda p: p["price"])["id"]
    if re.search(r"\b(that one|this one|that option|it|the one you mentioned)\b", value):
        if available(state, memory.last_plan):
            return memory.last_plan
    return None


def has_new_condition(text: str) -> bool:
    """A new limit in an approval utterance needs a recheck, not an old quote."""
    return bool(re.search(r"\b(but|unless|only if|provided|before|first|if|budget|limit|cap|spend|under|below|access|accessible|wheelchair|step free|stairs|overnight road|road travel)\b", norm(text)))


def explicit_plan_consent(text: str, plan: dict[str, Any]) -> bool:
    """Require an affirmative, plan-specific second turn; never trust model consent."""
    value = norm(text)
    if text.strip().endswith("?") or has_new_condition(text):
        return False
    if re.search(r"\b(no|not|never|dont|do not|stop|cancel|wait|maybe|perhaps|might|unsure|should i|could i|would i)\b", value):
        return False
    if re.match(r"^(what if|if|suppose|imagine|should|could|would)\b", value):
        return False
    affirmative = r"^(yes|yep|yeah|okay|ok|go ahead|please (?:book|confirm|approve|reserve)|confirm|approve|book|reserve|lets confirm|i (want to |would like to |am ready to )?(confirm|approve|book|reserve)|id like to (confirm|approve|book|reserve))\b"
    if not re.search(affirmative, value):
        return False
    # 'Confirm the train instead of the coach' must never confirm a pending coach.
    selected = value.split("instead of", 1)[0]
    plan_id = plan["id"]
    names = {
        "coach": r"\b(coach|bus)\b", "rail": r"\b(later train|new train|rail)\b",
        "car": r"\b(car|taxi|cab)\b", "royal-fern": r"\b(royal|fern)\b",
        "blue-lotus": r"\b(blue lotus|lotus)\b",
    }
    if plan_id == "rail" and "original train" in selected:
        return False
    # Do not treat two selected plans (or a second amount) as consent to either.
    # Bare 'train' is not specific enough to approve the *later* train, but it
    # still conflicts with an attempted coach/cab/room approval.
    competing_names = dict(names, rail=r"\b(train|rail)\b")
    if any(re.search(pattern, selected) for other_id, pattern in competing_names.items() if other_id != plan_id):
        return False
    amounts = [int(number) for number in re.findall(r"(?<!\d)\d{3,5}(?!\d)", selected)]
    if amounts and any(amount != plan["price"] for amount in amounts):
        return False
    amount = str(plan["price"])
    return bool(
        re.search(names.get(plan_id, r"(?!)"), selected)
        or re.search(rf"(?<!\d){amount}(?!\d)", selected.replace(",", ""))
    )


def local_decision(text: str, state: dict[str, Any], memory: ConversationMemory) -> dict[str, Any]:
    """Useful offline conversational fallback, not a claim of general AI understanding."""
    value = norm(text)
    actions: list[dict[str, Any]] = []
    if not value:
        return {"actions": [], "focus": "unknown", "reply": ""}
    if re.search(r"\b(aadhaar|aadhar|pan card|passport|identity documents|email access|inbox|vault)\b", value):
        return {"actions": [], "focus": "docs", "reply": ""}
    if re.search(r"\b(cancel|refund)\b.*\b(my )?(ticket|booking|hotel|flight|train|reservation)\b", value):
        return {"actions": [], "focus": "unsupported", "reply": ""}
    if memory.pending and (re.search(r"^(no|nah|nope|not now)\b", value)
                           or re.search(r"\b(dont|do not) (want to )?confirm\b", value)):
        return {"actions": [{"type": "cancel"}], "focus": "answer", "reply": ""}
    if memory.pending and memory.pending.get("kind") == "plan":
        changed_plan = plan_reference(text, state, memory)
        if changed_plan and changed_plan != memory.pending["plan_id"] and re.search(r"\b(book|choose|take|select|go with)\b", value):
            return {"actions": [{"type": "stage_plan", "plan_id": changed_plan}], "focus": "answer", "reply": ""}
    if re.search(r"\b(confirm|yes|approve|go ahead|okay|ok|book)\b", value) and memory.pending:
        kind = "confirm_reset" if memory.pending.get("kind") == "reset" and re.search(r"\b(restart|reset|start over)\b", value) else "confirm_plan"
        return {"actions": [{"type": kind}], "focus": "answer", "reply": ""}
    if re.search(r"\b(never mind|nevermind|forget it|cancel|hold off|not now|no thanks)\b", value) and not re.search(r"\b(cancelled|canceled)\b", value):
        return {"actions": [{"type": "cancel"}], "focus": "answer", "reply": ""}
    if re.search(r"\b(restart|reset|start over|begin again)\b", value):
        return {"actions": [{"type": "reset"}], "focus": "answer", "reply": ""}
    if re.search(r"\b(sold out|sell out|inventory changed|test failure|test sold)\b", value):
        return {"actions": [{"type": "sellout"}], "focus": "answer", "reply": ""}
    if re.search(r"\b(download|save|get a copy|send me)\b.*\b(plan|itinerary|summary)\b", value):
        return {"actions": [{"type": "download"}], "focus": "answer", "reply": ""}
    if re.search(r"\b(not worth|too expensive|dont want to spend|do not want to spend|spend nothing|stay nearby|stay in bengaluru|skip the trip|stop spending)\b", value):
        return {"actions": [], "focus": "pause", "reply": ""}

    budget = re.search(r"\b(?:budget|limit|cap|spend|pay|under|below|no more than|at most|maximum|extra)\b.{0,35}?(?:₹\s*)?([1-8][\d,]{2,4})\b", value)
    if budget and re.search(r"\b(budget|limit|cap|spend|pay|under|below|no more than|at most|maximum|extra)\b", value):
        amount = int(budget.group(1).replace(",", ""))
        if 500 <= amount <= 8000:
            actions.append({"type": "set_budget", "amount": amount})
    if re.search(r"\b(step free|stepfree|wheelchair|accessible|accessibility|no stairs)\b", value):
        off = bool(re.search(r"\b(no need|not needed|dont need|do not need|disable|turn off|remove)\b", value))
        actions.append({"type": "set_access", "enabled": not off})
    if re.search(r"\b(no (overnight )?(road|coach|bus)|avoid (the )?(overnight )?(road|coach|bus)|dont want (a |an |the )?(overnight )?(road|coach|bus|car|taxi)|do not want (a |an |the )?(overnight )?(road|coach|bus|car|taxi)|cant take (a |an |the )?(bus|coach|car|taxi)|no bus|no coach)\b", value):
        actions.append({"type": "set_road", "enabled": True})
    elif re.search(r"\b(road is fine|coach is fine|road is okay|allow (overnight )?road|turn off no road)\b", value):
        actions.append({"type": "set_road", "enabled": False})
    hypothetical = bool(re.search(r"^(what if|suppose|imagine|could|would|if)\b", value)) and not bool(re.search(r"\b(simulate|replay|test the scenario)\b", value))
    flight_mentioned = bool(re.search(r"\b(flight|plane|arrival)\b.{0,55}\b(delayed|delay|late|pushed back|running behind|moved back)\b|\b(delay|late)\b.{0,30}\b(flight|plane)\b", value))
    hotel_mentioned = bool(re.search(r"\b(hotel|room|stay)\b.{0,45}\b(cancelled|canceled|fell through|not available|dropped|lost)\b|\b(cancelled|canceled)\b.{0,20}\b(hotel|room)\b", value))
    if flight_mentioned and not hypothetical:
        actions.append({"type": "flight_delay"})
    if hotel_mentioned and not hypothetical:
        actions.append({"type": "hotel_cancelled"})
    if actions:
        # In a compound sentence, validate preferences before replaying disruption.
        actions.sort(key=lambda a: a["type"] in ("flight_delay", "hotel_cancelled"))
        return {"actions": actions[:3], "focus": "options", "reply": ""}
    if hypothetical and (flight_mentioned or hotel_mentioned):
        return {"actions": [], "focus": "scenario", "reply": ""}
    if re.search(r"\b(metro|traffic|road transfer|station transfer|original train|catch the train|make the train)\b", value):
        return {"actions": [], "focus": "transfer", "reply": ""}
    if re.search(r"\b(cheaper|cheapest|compare|difference|which one|which route|alternatives|options|what else|other way|how can i get|what can i do)\b", value):
        return {"actions": [], "focus": "compare", "reply": ""}
    reference = plan_reference(text, state, memory)
    plan = available(state, reference)
    if plan and re.search(r"\b(book|confirm|approve|choose|take|select|reserve|go with|lets do|ill do|i want|id like)\b", value):
        # The choices and exact prices were already shown. A clear, named
        # "Book the later train" can be the traveller's one approval turn.
        # Softer wording still stages a quote for an explicit second turn.
        kind = "book_plan" if memory.offer_matches(state, plan) and explicit_plan_consent(text, plan) else "stage_plan"
        return {"actions": [{"type": kind, "plan_id": reference}], "focus": "answer", "reply": ""}
    if reference:
        return {"actions": [{"type": "review_plan", "plan_id": reference}], "focus": "answer", "reply": ""}
    if (state["phase"] == "hotel_alert" and
            re.search(r"\b(keep|still have|what about|is my)\b.*\b(train|travel|journey)\b", value)):
        return {"actions": [], "focus": "status", "reply": ""}
    if re.search(r"\b(how am i|am i okay|status|what happened|where am i|whats (already )?confirmed|what do you know|tell me about my trip|show my trip|my itinerary|read my final plan|whats the plan|am i still going|will i make it|arrive on time|see (my )?mom|see (my )?mum)\b", value):
        return {"actions": [], "focus": "status", "reply": ""}
    if re.search(r"\b(price|cost|money|budget)\b", value):
        return {"actions": [], "focus": "options", "reply": ""}
    return {"actions": [], "focus": "unknown", "reply": ""}


ACTION_TYPES = {
    "flight_delay", "hotel_cancelled", "set_budget", "set_road", "set_access", "stage_plan",
    "review_plan", "book_plan", "confirm_plan", "cancel", "reset", "confirm_reset", "sellout", "download",
}
FOCI = {"answer", "status", "options", "compare", "transfer", "scenario", "pause", "docs", "unsupported", "unknown"}


def validate_decision(raw: dict[str, Any], state: dict[str, Any], memory: ConversationMemory) -> dict[str, Any]:
    """Model output is untrusted. Validate every tool name and argument."""
    actions = raw.get("actions", [])
    if not isinstance(actions, list):
        actions = []
    clean: list[dict[str, Any]] = []
    for action in actions[:3]:
        if not isinstance(action, dict) or action.get("type") not in ACTION_TYPES:
            continue
        kind = action["type"]
        if kind == "set_budget":
            amount = action.get("amount")
            if type(amount) is not int or not 500 <= amount <= 8000:
                continue
            clean.append({"type": kind, "amount": amount})
        elif kind in ("set_road", "set_access"):
            if type(action.get("enabled")) is not bool:
                continue
            clean.append({"type": kind, "enabled": action["enabled"]})
        elif kind in ("stage_plan", "review_plan", "book_plan"):
            plan_id = action.get("plan_id")
            if isinstance(plan_id, str) and available(state, plan_id):
                clean.append({"type": kind, "plan_id": plan_id})
        else:
            clean.append({"type": kind})
    # Apply a newly stated hard limit *before* considering a plan choice. Never
    # stage the old quote while silently discarding the limit in a compound turn.
    preferences = {"set_budget", "set_road", "set_access"}
    if (any(a["type"] in {"stage_plan", "review_plan", "book_plan"} for a in clean)
            and any(a["type"] in preferences for a in clean)):
        clean = [a for a in clean if a["type"] in preferences]
    # Never combine a confirmation, cancellation, reset or download with another action.
    isolated = {"confirm_plan", "confirm_reset", "cancel", "reset", "sellout", "download", "stage_plan", "review_plan", "book_plan"}
    if any(action["type"] in isolated for action in clean):
        clean = [next(action for action in clean if action["type"] in isolated)]
    focus = raw.get("focus") if raw.get("focus") in FOCI else "unknown"
    reply = raw.get("reply") if isinstance(raw.get("reply"), str) else ""
    return {"actions": clean, "focus": focus, "reply": reply.strip()[:430]}


def grounded_actions(actions: list[dict[str, Any]], text: str, state: dict[str, Any],
                     memory: ConversationMemory) -> list[dict[str, Any]]:
    """A model can interpret accents and phrasing, but cannot invent consent or loosen limits."""
    words = norm(text)
    chosen_clause = words.split("instead of", 1)[0]
    reference = plan_reference(chosen_clause, state, memory)
    result: list[dict[str, Any]] = []
    for action in actions:
        kind = action["type"]
        if kind == "set_budget":
            number = str(action["amount"])
            if not re.search(rf"(?<!\d){number}(?!\d)", words):
                continue
            if not re.search(r"\b(budget|limit|cap|spend|pay|under|below|maximum|extra|afford|no more than|at most)\b", words):
                continue
        elif kind == "set_road":
            if not re.search(r"\b(road|bus|coach|taxi|cab|car|drive|driving)\b", words):
                continue
            if action["enabled"] and not re.search(r"\b(no|not|avoid|dont|cant|refuse|rather not|uncomfortable)\b", words):
                continue
            if not action["enabled"] and not re.search(r"\b(allow|fine|okay|ok|comfortable|can take|willing|open to)\b", words):
                continue
        elif kind == "set_access":
            if not re.search(r"\b(access|accessible|accessibility|wheelchair|step free|stepfree|stairs)\b", words):
                continue
            if not action["enabled"] and not re.search(r"\b(no need|not needed|dont need|remove|disable|turn off)\b", words):
                continue
        elif kind == "flight_delay":
            if not (re.search(r"\b(flight|plane|jet|arrival)\b", words)
                    and re.search(r"\b(delay|delayed|late|behind|held|pushed back|moved back)\b", words)):
                continue
            if re.search(r"\b(not|never|isnt|wasnt) (?:\w+ ){0,2}(delay|delayed|late)\b", words):
                continue
        elif kind == "hotel_cancelled":
            if (not re.search(r"\b(hotel|room|stay|reservation)\b", words)
                    or not re.search(r"\b(cancelled|canceled|fell through|lost|no room|cant honour|cant honor|not available)\b", words)
                    or re.search(r"\b(cancel|please cancel|want to cancel) (my |the )?(hotel|room|stay|reservation)\b", words)):
                continue
        elif kind in ("stage_plan", "review_plan", "book_plan"):
            if reference != action["plan_id"]:
                continue
            if kind == "stage_plan" and not re.search(r"\b(book|choose|take|select|reserve|go with|want|prepare|lets do|ill do|id like)\b", words):
                continue
            if kind == "book_plan" and not explicit_plan_consent(text, available(state, reference)):
                continue
        elif kind == "sellout" and not re.search(r"\b(sold out|sell out|inventory|test failure|test sold)\b", words):
            continue
        elif kind in ("reset", "confirm_reset") and not re.search(r"\b(reset|restart|start over|begin again)\b", words):
            continue
        elif kind == "download" and not re.search(r"\b(download|save|get a copy|send me)\b", words):
            continue
        result.append(action)
    return result


def current_pending(memory: ConversationMemory, state: dict[str, Any]) -> dict[str, Any] | None:
    p = memory.pending
    if not p:
        return None
    if p["kind"] == "plan":
        plan = available(state, p["plan_id"])
        if not plan or (p["revision"] != state["revision"] and state.get("pending_fail_plan") != p["plan_id"]):
            memory.pending = None
            return None
        return {"kind": "plan", "plan_id": plan["id"], "title": plan["title"], "price": plan["price"], "revision": p["revision"]}
    return {"kind": "reset"}


def _status(state: dict[str, Any]) -> str:
    phase = state["phase"]
    if phase == "ready":
        return "In this sample, Ananya's Delhi flight is due in Bengaluru at 18:10, then she has a 20:35 train to Mysuru and The Tamarind House room. Nothing is disrupted yet. Want to replay the flight delay?"
    if phase == "flight_alert":
        return "The sample flight now arrives at 19:35; both assumed metro-linked and road transfers miss the original 20:35 train. No replacement is confirmed yet. I can compare safe options."
    if phase == "travel_secured":
        travel, stay = state["journey"][1:3]
        return (f"In the demo, {travel['title']} and {stay['title']} are currently confirmed. "
                "The original train ticket remains issued; its refund is pending and not counted as cash. "
                "Want to test what happens if the hotel cancels?")
    if phase == "hotel_alert":
        travel = state["journey"][1]
        return f"The {travel['title']} travel leg is still confirmed in the demo. The hotel cancelled, so only the stay needs repair. No replacement room is confirmed yet."
    travel, stay = state["journey"][1:3]
    return (f"Final demo plan: {travel['title']} arrives in Mysuru at {state['arrival_current']}; "
            f"the current stay is {stay['title']}. Net extra cash is {money(state['gross_extra'])}. "
            "The old train refund remains pending. No real reservation or payment was made.")


def _options(state: dict[str, Any]) -> str:
    if state["phase"] == "ready":
        return "There is no disruption yet. Tell me if the flight is delayed and I'll check the connected trip, not just the flight."
    if state["phase"] in ("travel_secured", "complete"):
        return _status(state)
    plans = state["plans"]
    if not plans:
        reasons = [r["reason"] for r in state["rejected"] if r["id"] != "original-train"][:2]
        detail = " ".join(reasons)
        return f"No safe option fits the current {money(state['preferences']['max_extra'])} extra-cash limit and travel rules. {detail} I won't pretend there's a booking. Want to revisit a limit or pause the trip?"
    ordered = sorted(plans, key=lambda p: p["price"])
    parts = [f"{p['title']}, {money(p['price'])} more, arriving {p['arrival_short']}" for p in ordered]
    return (f"I found {len(plans)} feasible {'room' if state['phase'] == 'hotel_alert' else 'route'}"
            f"{'s' if len(plans) != 1 else ''} in this demo: {'; '.join(parts)}. "
            "Shall I book one virtually? Say 'Book' and its name or price, or use its button. "
            "I'll recheck it first; no real payment or supplier is connected.")


def booking_reply(booking: dict[str, Any]) -> str:
    reserved = [step for step in booking["steps"] if step["reference"]]
    items = "; ".join(f"{step['app']} {step['kind']} for {money(step['price'])}"
                      for step in reserved)
    return (f"Done in the simulation: {booking['plan_title']} passed the final check. "
            f"I handled {items} with the saved fictional traveller profile. "
            "No real ticket, cab, room or payment was made.")


def _compare(state: dict[str, Any]) -> str:
    if len(state["plans"]) < 2:
        return _options(state)
    a, b = state["plans"][:2]
    cheaper, other = sorted((a, b), key=lambda p: p["price"])
    difference = other["price"] - cheaper["price"]
    if state["phase"] == "hotel_alert":
        return f"{cheaper['title']} is {money(difference)} cheaper than {other['title']}. Both are synthetic 24-hour options. Your confirmed travel stays untouched; which room feels right?"
    if {a['id'], b['id']} == {'coach', 'rail'}:
        return f"The {cheaper['title']} costs {money(cheaper['price'])}; {other['title']} costs {money(other['price'])}. The coach keeps the original room but uses overnight road travel; the later train gives a longer boarding window and a 24-hour hotel. Which would you prefer?"
    return f"{cheaper['title']} is {money(difference)} less than {other['title']}. They arrive at {cheaper['arrival_short']} and {other['arrival_short']} respectively. Which one should I explain?"


def _transfer(state: dict[str, Any]) -> str:
    prefix = "If we replay the delay, the sample flight arrives at 19:35" if state["phase"] == "ready" else "The sample flight arrives at 19:35"
    checks = {p["id"]: p for p in state["transfer_checks"]}
    road, metro = checks["road"], checks["metro-link"]
    return (f"{prefix}. With 35 minutes for bags and 15 to board, an optimistic {road['transfer_min']}-minute road "
            f"transfer is ready at {road['ready_to_board']}—{-road['slack_min']} minutes after the 20:35 train. "
            f"A hypothetical metro-linked path is ready at {metro['ready_to_board']}—{-metro['slack_min']} minutes late. "
            "Neither is a live route or traffic check; a real service must verify both before ruling out that train.")


def _docs() -> str:
    return "In a real product, the itinerary would come from separately authorised email access, and previously stored passenger documents would be used only if a booking provider requires them. This demo has neither connection. Please don't share ID numbers here."


def _unsupported() -> str:
    return "I can't cancel, refund, or book a real reservation here. I haven't changed any supplier booking. If this is a real trip, contact the provider or a human agent."


def _scenario(state: dict[str, Any]) -> str:
    if state["phase"] == "ready":
        return "If the sample flight were delayed to 19:35, the original train would fail the demo transfer allowance. I could then compare a coach and a later train. Shall I replay that disruption?"
    if state["phase"] == "travel_secured":
        return "If the hotel cancels in this demo, the confirmed replacement travel stays as it is. I'd look only for a new room. Want me to replay that event?"
    return "The sample disruption has already been replayed. I can explain the current options without changing anything."


def _pause() -> str:
    return ("That's reasonable. I won't prepare a paid rescue. You could travel to Mysuru more slowly tomorrow "
            "or stay safely near Bengaluru tonight; if you make a day of it, consider Cubbon Park or Lalbagh "
            "after checking opening hours. Stays can still cost money, and no local availability or route is live-checked here.")


def _general(state: dict[str, Any]) -> str:
    if state["phase"] == "ready":
        return "I'm here with Ananya's sample trip. Is your question about the connection, the budget, or what happens if her flight is delayed?"
    if state["phase"] == "complete":
        return "The demo trip is repaired. I can explain the final route, extra cash, or what still needs provider action. What would help most?"
    return "I can look at the connection, compare today's feasible options, or change the travel limits. What are you worried about most?"


def _safe_answer(reply: str, state: dict[str, Any], focus: str) -> str:
    """Free-form model wording is for conversation, never for operational claims."""
    if focus not in ("answer", "unknown") or not reply:
        return ""
    # Even a *correct-looking* amount or provider claim should come from the engine,
    # not a language-model sentence that happens to quote the sample itinerary.
    if "₹" in reply or re.search(r"\b(booked|ticketed|reserved|confirmed|paid|charged|cancelled|canceled|refunded|issued|uploaded|accessed|sent|guaranteed)\b", reply, re.I):
        return ""
    if re.search(r"\b(live|real.time|fresh|up.to.date)\b|\b(available seats|current inventory|checked traffic)\b", reply, re.I):
        return ""
    return reply.strip()[:430]


def _suggestions(state: dict[str, Any], pending: dict[str, Any] | None) -> list[str]:
    if pending:
        if pending["kind"] == "reset":
            return ["Yes, restart the demo", "No, keep this trip"]
        name = {"coach": "coach", "rail": "later train", "car": "car", "royal-fern": "Royal Fern", "blue-lotus": "Blue Lotus"}.get(pending["plan_id"], pending["title"])
        return [f"Yes, confirm the {name} for {money(pending['price'])}", "No, show me other options"]
    return {
        "ready": ["My flight's running late. Can I still make it?", "What do you know about my trip?"],
        "flight_alert": ["What's the cheapest safe way?", "I'd rather avoid overnight road travel"],
        "travel_secured": ["My hotel just cancelled. What now?", "What's already confirmed?"],
        "hotel_alert": ["Which room keeps me under budget?", "Can I keep my train?"],
        "complete": ["Read my final plan", "Download my demo itinerary"],
    }[state["phase"]]


def present_context(engine: TripEngine, memory: ConversationMemory) -> dict[str, Any]:
    state = engine.snapshot()
    pending = current_pending(memory, state)
    return {"pending": pending, "suggestions": _suggestions(state, pending)}


def respond(engine: TripEngine, memory: ConversationMemory, text: str, decision: dict[str, Any] | None = None, mode: str = "guided") -> dict[str, Any]:
    """Return a brief, truthful answer plus updated state. Call under a session lock."""
    clean_text = redact(text)
    state = engine.snapshot()
    old_pending = memory.pending
    current_pending(memory, state)
    expired = old_pending is not None and memory.pending is None
    raw = decision if isinstance(decision, dict) else local_decision(clean_text, state, memory)
    parsed = validate_decision(raw, state, memory)
    if mode == "ai":
        proposed = parsed["actions"]
        parsed["actions"] = grounded_actions(proposed, clean_text, state, memory)
        if proposed and not parsed["actions"]:
            # If the model inferred an ungrounded action, prefer an honest local answer.
            parsed = validate_decision(local_decision(clean_text, state, memory), state, memory)
            mode = "guided"
    # A name-and-price specific command after displayed choices is decided by
    # the safety kernel, never by an LLM's asserted purchase intent.
    if not memory.pending:
        direct = validate_decision(local_decision(clean_text, state, memory), state, memory)
        if direct["actions"] and direct["actions"][0]["type"] == "book_plan":
            parsed = direct
            mode = "guided"  # Even if speech used cloud STT, the approval gate was local.
    expired_reply = ""
    if expired and re.search(r"\b(confirm|yes|approve)\b", norm(clean_text)):
        parsed = {"actions": [], "focus": "answer", "reply": ""}
        expired_reply = "That review expired when the trip changed. Nothing was booked. Let's review a current option again."
    if mode == "ai" and not parsed["actions"] and parsed["focus"] == "unknown":
        # Preserve a useful demo when the model declines or returns unusable JSON.
        parsed = validate_decision(local_decision(clean_text, state, memory), state, memory)
        mode = "guided"
    actions = parsed["actions"]
    focus = parsed["focus"]
    words = norm(clean_text)
    polite_request = bool(re.search(r"^(could|would) you\b.*\b(book|prepare|choose|select|reserve|replay|simulate)\b", words))
    hypothetical = (bool(re.search(r"^(what if|suppose|imagine|if|could|would|should)\b", words))
                    and not polite_request
                    and not bool(re.search(r"\b(simulate|replay|test the scenario)\b", words)))
    if hypothetical:
        actions = [a for a in actions if a["type"] not in {"flight_delay", "hotel_cancelled", "stage_plan", "book_plan", "confirm_plan", "set_budget", "set_road", "set_access"}]
        if not actions:
            focus = ("transfer" if re.search(r"\b(metro|transfer|original train)\b", words)
                     else "scenario" if re.search(r"\b(flight|hotel|room|delayed|cancelled)\b", words)
                     else "compare")
    actions = [a for a in actions if
               a["type"] != "flight_delay" or re.search(r"\b(flight|plane|delay|late)\b", words)]
    actions = [a for a in actions if
               a["type"] != "hotel_cancelled" or re.search(r"\b(hotel|room|stay|cancel)\b", words)]
    answer = expired_reply
    booking: dict[str, Any] | None = None
    download = False
    restarted = False
    changed: list[str] = []
    try:
        for action in actions:
            kind = action["type"]
            if kind == "set_budget":
                engine.set_preferences({"max_extra": action["amount"]})
                memory.pending = None
                changed.append(f"Extra-cash limit set to {money(action['amount'])}")
            elif kind in ("set_road", "set_access"):
                label = "No overnight road travel" if kind == "set_road" else "Verified step-free access"
                key = "avoid_overnight_road" if kind == "set_road" else "step_free_only"
                engine.set_preferences({key: action["enabled"]})
                memory.pending = None
                changed.append(f"{label} {'on' if action['enabled'] else 'off'}")
            elif kind == "flight_delay":
                if engine.phase == "ready":
                    engine.disrupt_flight()
                    changed.append("Sample flight delay replayed")
                else:
                    changed.append("That flight delay is already part of this demo")
            elif kind == "hotel_cancelled":
                if engine.phase == "travel_secured":
                    engine.disrupt_hotel()
                    changed.append("Sample hotel cancellation replayed; confirmed travel kept")
                else:
                    changed.append("A replacement journey must be chosen before that second sample event")
            elif kind == "review_plan":
                plan = available(engine.snapshot(), action["plan_id"])
                if not plan:
                    answer = "That option isn't feasible under your current limits. Let me show you the current choices."
                else:
                    memory.pending = None
                    memory.last_plan = plan["id"]
                    detail = "Your confirmed travel stays as it is." if plan["kind"] == "hotel" else f"{plan['margin']}; {plan['hotel_margin']}."
                    answer = f"{plan['title']} is {money(plan['price'])} more, arriving {plan['arrival_short']}. {detail} Want me to prepare it for a demo confirmation?"
            elif kind == "book_plan":
                fresh = engine.snapshot()
                plan = available(fresh, action["plan_id"])
                if not plan or not memory.offer_matches(fresh, plan) or not explicit_plan_consent(clean_text, plan):
                    answer = "That choice needs a fresh, specific approval. Nothing was booked. Please review the current name and price."
                else:
                    _, booking = GATEWAY.book(engine, plan["id"], memory.offered["revision"],
                                              memory.offered["prices"][plan["id"]])
                    memory.pending = None
                    memory.last_plan = plan["id"]
                    answer = booking_reply(booking)
            elif kind == "stage_plan":
                plan = available(engine.snapshot(), action["plan_id"])
                if not plan:
                    answer = "That quote is no longer feasible. Nothing was changed; let's look at the current options."
                else:
                    memory.last_plan = plan["id"]
                    memory.pending = {"kind": "plan", "plan_id": plan["id"], "revision": engine.revision}
                    name = {"coach": "coach", "rail": "later train", "car": "cab", "royal-fern": "Royal Fern", "blue-lotus": "Blue Lotus"}.get(plan["id"], plan["title"])
                    answer = (f"{plan['title']} costs {money(plan['price'])} extra, arriving {plan['arrival_short']}. "
                              f"Shall I virtually book the {name} and any required room using the saved sample details? "
                              "Say yes with its name, or tap Confirm. No real payment.")
            elif kind == "confirm_plan":
                pending = current_pending(memory, engine.snapshot())
                if not pending or pending["kind"] != "plan":
                    answer = "That review has expired; no action was taken. Let's choose a current option again." if expired else "There isn't a plan awaiting approval. Which option should we review?"
                else:
                    plan = available(engine.snapshot(), pending["plan_id"])
                    if has_new_condition(clean_text):
                        memory.pending = None
                        answer = "I heard another condition, so I dropped the old review. Nothing was confirmed. Tell me that limit or access need on its own and I'll check the options again."
                    elif not plan or not explicit_plan_consent(clean_text, plan):
                        answer = f"Just to be safe, please say 'yes, confirm the {plan['title'] if plan else 'plan'}' or tap Confirm. Nothing has changed."
                    else:
                        memory.pending = None
                        _, booking = GATEWAY.book(engine, plan["id"], pending["revision"], pending["price"])
                        answer = booking_reply(booking)
            elif kind == "cancel":
                memory.pending = None
                answer = "Of course. I dropped the pending review; no booking or cancellation was made."
            elif kind == "reset":
                memory.pending = {"kind": "reset"}
                answer = "Restarting would erase this sample trip. Do you want to restart the demo? Say yes, restart, or tap Confirm."
            elif kind == "confirm_reset":
                if memory.pending and memory.pending["kind"] == "reset" and re.search(r"\b(restart|reset|start over)\b", norm(clean_text)) and not re.search(r"\b(no|not|dont|wait)\b", norm(clean_text)):
                    engine.__init__()  # The demo session has no external side effects.
                    memory.reset()
                    restarted = True
                    answer = "The sample trip is reset. What would you like to ask?"
                else:
                    answer = "To restart the demo, please say 'yes, restart the demo' or tap Confirm."
            elif kind == "sellout":
                pending = current_pending(memory, engine.snapshot())
                if pending and pending["kind"] == "plan":
                    engine.mark_offer_sold_out(pending["plan_id"])
                    answer = "The sample supplier changed that offer. Try confirming to see the safe stop; no payment or cancellation has happened."
                else:
                    answer = "First prepare one of the current demo options; then we can test a sold-out quote."
            elif kind == "download":
                if engine.phase == "complete":
                    download = True
                    answer = "I'm downloading your labelled demo itinerary. It's not a real ticket or room confirmation."
                else:
                    answer = "We can download the demo itinerary after the sample recovery is complete."
    except TripError as exc:
        memory.pending = None
        answer = str(exc)

    state = engine.snapshot()
    if changed:
        summary = ". ".join(changed) + ". "
        if state["phase"] in ("flight_alert", "hotel_alert"):
            answer = summary + _options(state)
        else:
            answer = summary + _status(state)
    if not answer:
        if focus == "status":
            answer = _status(state)
        elif focus == "options":
            answer = _options(state)
        elif focus == "compare":
            answer = _compare(state)
        elif focus == "transfer":
            answer = _transfer(state)
        elif focus == "scenario":
            answer = _scenario(state)
        elif focus == "docs":
            answer = _docs()
        elif focus == "unsupported":
            memory.pending = None
            answer = _unsupported()
        elif focus == "pause":
            memory.pending = None
            answer = _pause()
        else:
            answer = _safe_answer(parsed["reply"], state, focus) or _general(state)
    answer = answer.strip()[:720]
    memory.show_offers(state)  # The response displays these exact option cards and prices.
    memory.remember(clean_text, answer)
    return {
        "reply": answer,
        "state": state,
        "booking": booking,
        "pending": current_pending(memory, state),
        "suggestions": _suggestions(state, current_pending(memory, state)),
        "mode": mode,
        "download": download,
        "restarted": restarted,
    }
