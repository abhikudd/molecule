/* Optional Playwright CLI smoke test for the voice-first Trip Rescue page.
 * No real microphone or cloud account is used. Cloud routes and speech APIs are mocked.
 * Run: playwright-cli -s=arena run-code --filename=test_voice_browser.js
 */
async (page) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (message) => {if (['error','warning'].includes(message.type())) errors.push(message.text());});
  await page.addInitScript(() => {
    window.__speechQueue = [];
    window.__recognizerStarts = 0;
    window.SpeechRecognition = class MockRecognition {
      start() {
        window.__recognizerStarts++;
        this.onstart?.();
        this.timer = setTimeout(() => {
          const phrase = window.__speechQueue.shift();
          if (phrase) {
            const result = Object.assign([{transcript: phrase}], {isFinal: true});
            this.onresult?.({results: [result]});
          }
          this.onend?.();
        }, 150);
      }
      stop() { clearTimeout(this.timer); this.onend?.(); }
      abort() { clearTimeout(this.timer); this.onend?.(); }
    };
  });
  await page.setViewportSize({width: 375, height: 812});
  await page.goto('http://127.0.0.1:8000/');
  await page.evaluate(async () => {
    await fetch('/api/reset', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-Trip-Session': sessionStorage.getItem('trip-rescue-demo-session')}, body: '{}'
    });
  });
  await page.reload();
  await page.locator('#soundButton').click();
  if (await page.locator('#micButton').isDisabled()) throw new Error('Mock browser speech mic is disabled.');
  if (await page.locator('#overviewMount li').count() !== 3 ||
      !(await page.locator('#overviewBudget').innerText()).includes('2,500') ||
      !(await page.locator('#clarityTitle').innerText()).includes('A clear way forward'))
    throw new Error('Essential trip, guardrail or how-it-works sections are missing.');
  await page.evaluate(() => window.__speechQueue.push("My flight's running late. Can I still make it?"));
  await page.locator('#micButton').click();
  await page.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Recovery choices ready'));
  if (!(await page.locator('#conversationLog').innerText()).includes("My flight's running late"))
    throw new Error('Spoken transcript did not appear in the conversation.');
  if (await page.locator('#optionMount .option-card').count() !== 2)
    throw new Error('Spoken delay did not produce two feasible routes.');
  if (!(await page.locator('#overviewMount').innerText()).includes('Connection missed'))
    throw new Error('Connected-trip overview failed to reflect the missed train.');
  const mobileLayout = await page.evaluate(() => {
    const conversation = document.querySelector('#conversationScroll');
    return {overflow: conversation.scrollHeight > conversation.clientHeight + 2,
      micTop: document.querySelector('#micButton').getBoundingClientRect().top,
      width: document.documentElement.scrollWidth};
  });
  if (mobileLayout.overflow || mobileLayout.micTop > 812 || mobileLayout.width > 375)
    throw new Error('Mobile plans hid the mic or trapped cards in a tiny nested scroll area.');

  // End must discard any queued recognition and prevent an unwanted booking action.
  await page.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Start speaking');
  await page.evaluate(() => window.__speechQueue.push('Book the coach'));
  await page.locator('#micButton').click();
  await page.locator('#endConversation').click();
  await page.waitForTimeout(240);
  await page.evaluate(() => window.__speechQueue.length = 0);
  if ((await page.locator('#conversationLog').innerText()).includes('Book the coach'))
    throw new Error('End submitted a discarded spoken request.');

  // Listen-again is opt-in and must understand a contextual follow-up.
  await page.locator('.auto-listen').click();
  await page.evaluate(() => window.__speechQueue.push('Tell me about the later train', 'Okay, I want that one'));
  await page.locator('#micButton').click();
  await page.waitForFunction(() => document.querySelector('#confirmationMount').textContent.includes('Later train'), null, {timeout: 10000});
  if (await page.evaluate(() => window.__recognizerStarts < 3))
    throw new Error('Opt-in listen-again did not start the next turn.');
  if (await page.locator('#autoListen').isChecked()) await page.locator('.auto-listen').click();
  await page.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Start speaking');
  await page.locator('#messageInput').fill('yes');
  await page.locator('#messageForm button').click();
  await page.waitForFunction(() => document.querySelector('#conversationLog').textContent.includes('Just to be safe'));
  if (!(await page.locator('#confirmationMount').innerText()).includes('Later train'))
    throw new Error('Generic yes incorrectly approved the quote.');
  await page.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Start speaking');
  await page.evaluate(() => window.__speechQueue.push('Yes, confirm the later train'));
  await page.locator('#micButton').click();
  await page.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Travel route secured'));
  const receipt = await page.locator('#bookingMount').innerText();
  if (!receipt.includes('Virtual Rail App') || !receipt.includes('Virtual Stay App') ||
      !receipt.includes('DEMO-TR-') || !receipt.includes('DEMO-HT-') || !receipt.includes('NO REAL PURCHASE'))
    throw new Error('Spoken approval did not automate both labelled virtual app steps.');
  if (!(await page.locator('#overviewMount').innerText()).includes('Demo confirmed') ||
      !(await page.locator('#overviewSpent').innerText()).includes('2,140') ||
      !(await page.locator('#overviewRemaining').innerText()).includes('360'))
    throw new Error('Trip overview failed to update its connected status and cash guardrail.');
  await page.locator('#overviewDetailsButton').click();
  if (!(await page.locator('#tripDetails').evaluate((node) => node.open)) ||
      !(await page.locator('#ledgerMount').innerText()).includes('simulation'))
    throw new Error('The full-trip disclosure did not open to the action record.');
  if (await page.evaluate(() => document.documentElement.scrollWidth > innerWidth))
    throw new Error('Mobile conversation caused horizontal overflow.');

  // After prices are spoken/shown, one specific voice answer books without another turn.
  await page.evaluate(async () => {
    await fetch('/api/reset', {method:'POST', headers:{'Content-Type':'application/json',
      'X-Trip-Session':sessionStorage.getItem('trip-rescue-demo-session')}, body:'{}'});
  });
  await page.reload();
  await page.locator('#soundButton').click();
  await page.locator('#messageInput').fill('My flight is delayed');
  await page.locator('#messageForm button').click();
  await page.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Recovery choices ready'));
  await page.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Start speaking');
  await page.evaluate(() => window.__speechQueue.push('Yes, book the coach for 1150'));
  await page.locator('#micButton').click();
  await page.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Travel route secured'));
  if (!(await page.locator('#bookingMount').innerText()).includes('Virtual Coach App'))
    throw new Error('Direct spoken approval did not trigger the virtual coach booking.');

  // Browser with no recognition keeps the full typed flow.
  const fallback = await page.context().newPage();
  try {
    fallback.on('pageerror', (error) => errors.push(error.message));
    fallback.on('console', (message) => {if (['error','warning'].includes(message.type())) errors.push(message.text());});
    await fallback.addInitScript(() => {window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined;});
    await fallback.setViewportSize({width: 320, height: 568});
    await fallback.goto(page.url());
    await fallback.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Everything is still connected'));
    const readyPhone = await fallback.evaluate(() => {
      document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, 0);
      return {micBottom:document.querySelector('#micButton').getBoundingClientRect().bottom,
        width:document.documentElement.scrollWidth, viewport:innerWidth};
    });
    if (readyPhone.micBottom > 568 || readyPhone.width > readyPhone.viewport)
      throw new Error(`Ready screen clipped the mic on a small phone: ${JSON.stringify(readyPhone)}`);
    if (!(await fallback.locator('#micButton').isDisabled())) throw new Error('Mic should be disabled without voice support.');
    if (!(await fallback.locator('#micHint').innerText()).includes('unavailable')) throw new Error('Voice limitation not labelled.');
    await fallback.locator('#messageInput').fill('My flight is delayed');
    await fallback.locator('#messageForm button').click();
    await fallback.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Recovery choices ready'));
    const narrow = await fallback.evaluate(() => ({micBottom:document.querySelector('#micButton').getBoundingClientRect().bottom,
      width:document.documentElement.scrollWidth, viewport:innerWidth}));
    if (narrow.micBottom > 568 || narrow.width > narrow.viewport)
      throw new Error(`Narrow phone lost mic or overflowed: ${JSON.stringify(narrow)}`);
    await fallback.locator('[data-plan-book="coach"]').click();
    await fallback.waitForFunction(() => document.querySelector('#statusMount').textContent.includes('Travel route secured'));
    const oneTap = await fallback.locator('#bookingMount').innerText();
    if (!oneTap.includes('Virtual Coach App') || !oneTap.includes('NO REAL PURCHASE') || !oneTap.includes('Kept'))
      throw new Error('One-tap demo booking did not preserve the room and show a labelled receipt.');
  } finally { await fallback.close(); }

  // A quote change then a final sold-out check must fail without a receipt or charge.
  const failure = await page.context().newPage();
  try {
    failure.on('pageerror', (error) => errors.push(error.message));
    failure.on('console', (message) => {
      // These two 409 network messages are expected, handled safe-stop responses.
      if (['error','warning'].includes(message.type()) && !message.text().includes('status of 409 (Conflict)')) errors.push(message.text());
    });
    await failure.goto(page.url());
    await failure.locator('#soundButton').click();
    await failure.locator('#messageInput').fill('Flight delayed');
    await failure.locator('#messageForm button').click();
    await failure.waitForFunction(() => document.querySelector('#optionMount [data-plan-book="coach"]'));
    await failure.evaluate(async () => {
      await fetch('/api/offer/sellout', {method:'POST', headers:{'Content-Type':'application/json',
        'X-Trip-Session':sessionStorage.getItem('trip-rescue-demo-session')}, body:JSON.stringify({plan_id:'coach'})});
    });
    await failure.locator('[data-plan-book="coach"]').click();
    await failure.waitForFunction(() => document.querySelector('#conversationLog').textContent.includes('offer or price has changed'));
    await failure.locator('[data-plan-book="coach"]').click();
    await failure.waitForFunction(() => document.querySelector('#conversationLog').textContent.includes('sold out'));
    if (await failure.locator('#bookingMount').innerText()) throw new Error('Sold-out quote showed a confirmation card.');
    if (await failure.locator('[data-plan-book="coach"]').count()) throw new Error('Sold-out coach remained offered.');
    if (!(await failure.locator('[data-plan-book="rail"]').count())) throw new Error('Safe backup option disappeared.');
  } finally { await failure.close(); }

  // Cloud UI path: fake MediaRecorder and fake response; verify audio only sent after tap.
  const cloud = await page.context().newPage();
  try {
    cloud.on('pageerror', (error) => errors.push(error.message));
    cloud.on('console', (message) => {if (['error','warning'].includes(message.type())) errors.push(message.text());});
    await cloud.addInitScript(() => {
      Object.defineProperty(navigator, 'mediaDevices', {configurable: true, value: {
        getUserMedia: async () => ({getTracks: () => [{stop() {}}]})
      }});
      window.AudioContext = undefined;
      window.webkitAudioContext = undefined;
      window.MediaRecorder = class MockRecorder {
        static isTypeSupported(type) {return type.startsWith('audio/webm');}
        constructor(_stream, opts) {this.mimeType = opts.mimeType; this.state = 'inactive';}
        start() {this.state = 'recording';}
        stop() {
          this.state = 'inactive';
          this.ondataavailable?.({data: new Blob([new Uint8Array(240)], {type: this.mimeType})});
          this.onstop?.();
        }
      };
    });
    await cloud.route('**/api/capabilities', route => route.fulfill({json: {ai_enabled: true, mode: 'ai', notice: 'mock'}}));
    let uploads = 0;
    let baseState;
    await cloud.route('**/api/voice', route => {
      uploads++;
      if (!route.request().headers()['content-type'].startsWith('audio/webm') || route.request().postDataBuffer().length < 100)
        throw new Error('The cloud voice request was not a bounded audio blob.');
      return route.fulfill({json: {transcript: 'My flight is delayed', reply: 'Mock cloud response; no trip change.',
        state: baseState, pending: null, suggestions: [], mode: 'ai'}});
    });
    await cloud.goto(page.url());
    await cloud.waitForFunction(() => document.querySelector('#modeBadge').textContent === 'AI VOICE READY');
    baseState = await cloud.evaluate(async () => {
      const response = await fetch('/api/state', {headers: {'X-Trip-Session': sessionStorage.getItem('trip-rescue-demo-session')}});
      return (await response.json()).state;
    });
    await cloud.locator('#soundButton').click();
    if (uploads !== 0) throw new Error('Cloud audio was sent before a microphone tap.');
    await cloud.locator('#micButton').click();
    await cloud.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Finish speaking');
    await cloud.locator('#micButton').click();
    await cloud.waitForFunction(() => document.querySelector('#conversationLog').textContent.includes('Mock cloud response'));
    if (uploads !== 1 || !(await cloud.locator('#conversationLog').innerText()).includes('My flight is delayed'))
      throw new Error('Cloud voice transcript/reply path failed.');
    await cloud.waitForFunction(() => document.querySelector('#micButton').getAttribute('aria-label') === 'Start speaking');
    await cloud.locator('#micButton').click();
    await cloud.waitForFunction(() => document.querySelector('#endConversation').hidden === false);
    await cloud.locator('#endConversation').click();
    await cloud.waitForTimeout(130);
    if (uploads !== 1) throw new Error('End uploaded a discarded recording.');
  } finally { await cloud.close(); }

  if (errors.length) throw new Error(`Browser errors: ${errors.join(' | ')}`);
  console.log('Voice and typed approvals, virtual booking apps, one-tap coach, safe consent, mocked cloud input, mobile widths, and zero browser errors passed.');
}
