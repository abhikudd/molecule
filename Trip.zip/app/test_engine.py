"""Deterministic checks for the Trip Rescue simulated recovery engine."""
import unittest
from unittest.mock import patch

from engine import ALTERNATE_HOTEL, HOTEL_RESCUES, TripEngine, TripError


class TripRescueTests(unittest.TestCase):
    def setUp(self):
        self.trip = TripEngine()

    def approve_current(self, plan_id):
        return self.trip.approve(plan_id, self.trip.revision)

    def test_original_trip_and_delayed_impact(self):
        self.assertEqual(self.trip.snapshot()["phase"], "ready")
        self.trip.disrupt_flight()
        view = self.trip.snapshot()
        self.assertEqual(view["phase"], "flight_alert")
        self.assertEqual(view["journey"][1]["status"], "Connection missed")
        self.assertEqual([p["id"] for p in view["plans"]], ["coach", "rail"])
        self.assertEqual(view["plans"][0]["margin"], "40 min to board")
        self.assertEqual(view["plans"][1]["margin"], "65 min to board")
        self.assertIn("65-minute", view["plans"][1]["description"])
        self.assertTrue(any(item["id"] == "car" for item in view["rejected"]))
        self.assertTrue(any(item["id"] == "original-train" for item in view["rejected"]))

    def test_original_train_is_rejected_only_after_two_sample_transfer_checks(self):
        self.trip.disrupt_flight()
        view = self.trip.snapshot()
        checks = {p["id"]: p for p in view["transfer_checks"]}
        self.assertEqual(checks["road"]["ready_to_board"], "21:10")
        self.assertEqual(checks["road"]["slack_min"], -35)
        self.assertEqual(checks["metro-link"]["ready_to_board"], "21:35")
        self.assertEqual(checks["metro-link"]["slack_min"], -60)
        self.assertTrue(all(not p["feasible"] for p in checks.values()))
        reason = next(p["reason"] for p in view["rejected"] if p["id"] == "original-train")
        self.assertIn("road transfer", reason)
        self.assertIn("metro-linked", reason)
        self.assertIn("neither transfer is live-checked", reason.lower())

    def test_hard_constraints_and_honest_infeasibility(self):
        self.trip.disrupt_flight()
        self.trip.set_preferences({"max_extra": 1000, "avoid_overnight_road": True})
        view = self.trip.snapshot()
        self.assertTrue(view["no_feasible"])
        self.assertFalse(view["plans"])
        self.assertEqual(view["gross_extra"], 0)
        self.assertTrue(any(r["id"] == "original-train" for r in view["rejected"]))
        self.trip.set_preferences({"max_extra": 2500})
        self.assertEqual([p["id"] for p in self.trip.snapshot()["plans"]], ["rail"])

    def test_accessibility_never_assumed(self):
        self.trip.disrupt_flight()
        self.trip.set_preferences({"step_free_only": True})
        self.assertEqual([p["id"] for p in self.trip.snapshot()["plans"]], ["rail"])
        self.assertTrue(any("not been verified" in r["reason"] for r in self.trip.snapshot()["rejected"]))

    def test_step_free_requirement_covers_the_stay_too(self):
        self.trip.disrupt_flight()
        self.trip.set_preferences({"step_free_only": True})
        self.assertIn("step-free travel, transfer and stay verified", self.trip.snapshot()["plans"][0]["source"])
        with patch.dict(ALTERNATE_HOTEL, {"accessible": False}):
            view = self.trip.snapshot()
            self.assertTrue(view["no_feasible"])
            self.assertTrue(any("night stay" in r["reason"] for r in view["rejected"]))

    def test_booking_is_simulated_and_original_train_remains_issued(self):
        self.trip.disrupt_flight()
        self.approve_current("coach")
        view = self.trip.snapshot()
        self.assertEqual(view["phase"], "travel_secured")
        self.assertEqual(view["gross_extra"], 1150)
        self.assertEqual(view["journey"][2]["time"], "00:30 expected check-in")
        self.assertTrue(any("DEMO-TR" in a["detail"] for a in view["actions"]))
        self.assertTrue(any(a["title"] == "Original train refund" and a["state"] == "pending" for a in view["actions"]))

    def test_second_event_preserves_transport_and_recovers_room(self):
        self.trip.disrupt_flight()
        self.approve_current("coach")
        self.trip.disrupt_hotel()
        view = self.trip.snapshot()
        self.assertEqual(view["phase"], "hotel_alert")
        self.assertEqual(view["journey"][1]["status"], "Demo confirmed")
        self.assertEqual([p["id"] for p in view["plans"]], ["royal-fern"])
        self.assertTrue(any(a["title"] == "Earlier room confirmation · superseded" and a["state"] == "superseded" for a in view["actions"]))
        self.approve_current("royal-fern")
        view = self.trip.snapshot()
        self.assertEqual(view["phase"], "complete")
        self.assertEqual(view["gross_extra"], 2240)
        self.assertEqual(view["journey"][1]["title"], "Bengaluru Airport → Mysuru")
        self.assertTrue(any(a["title"] == "Hotel cancelled by supplier · simulation" and a["state"] == "superseded" for a in view["actions"]))
        self.assertTrue(any(a["title"] == "New room confirmed · simulation" and a["state"] == "verified" for a in view["actions"]))

    def test_new_hard_limit_cannot_be_satisfied_by_hotel_only_repair(self):
        self.trip.disrupt_flight()
        self.approve_current("coach")
        self.trip.disrupt_hotel()
        self.trip.set_preferences({"avoid_overnight_road": True, "step_free_only": True})
        view = self.trip.snapshot()
        self.assertEqual(view["journey"][1]["status"], "Demo confirmed")
        self.assertTrue(view["no_feasible"])
        self.assertTrue(any("Confirmed road travel" in reason for reason in view["active_conflicts"]))
        self.assertTrue(any("travel leg lacks verified step-free" in r["reason"] for r in view["rejected"]))
        self.trip.set_preferences({"avoid_overnight_road": False, "step_free_only": False})
        self.assertEqual([p["id"] for p in self.trip.snapshot()["plans"]], ["royal-fern"])

    def test_newly_booked_hotel_refund_requires_confirmation(self):
        self.trip.disrupt_flight()
        self.approve_current("rail")
        self.trip.disrupt_hotel()
        view = self.trip.snapshot()
        self.assertEqual(view["refund_confirmed"], 1450)
        self.assertEqual(view["gross_extra"], 690)
        self.assertEqual([p["id"] for p in view["plans"]], ["royal-fern", "blue-lotus"])
        self.assertFalse(any(a["title"] == "Replacement room confirmed · simulation" and a["state"] == "verified" for a in view["actions"]))
        self.approve_current("royal-fern")
        self.assertEqual(self.trip.snapshot()["gross_extra"], 1780)
        self.assertEqual(self.trip.snapshot()["journey"][2]["time"], "01:33 expected check-in")
        self.assertTrue(any(a["title"] == "Original hotel cancellation" and a["state"] == "pending" for a in self.trip.snapshot()["actions"]))

    def test_second_repair_rechecks_access_for_the_new_hotel(self):
        self.trip.disrupt_flight()
        self.approve_current("rail")
        self.trip.disrupt_hotel()
        self.trip.set_preferences({"step_free_only": True})
        with patch.dict(HOTEL_RESCUES[0], {"accessible": False}):
            view = self.trip.snapshot()
            self.assertEqual([p["id"] for p in view["plans"]], ["blue-lotus"])
            self.assertTrue(any(r["id"] == "royal-fern" for r in view["rejected"]))

    def test_offer_fails_safely_at_final_check(self):
        self.trip.disrupt_flight()
        reviewed_revision = self.trip.revision
        self.trip.mark_offer_sold_out("coach")
        with self.assertRaises(TripError) as ctx:
            self.trip.approve("coach", reviewed_revision)
        self.assertEqual(ctx.exception.code, 409)
        view = self.trip.snapshot()
        self.assertEqual(view["phase"], "flight_alert")
        self.assertEqual(view["gross_extra"], 0)
        self.assertEqual([p["id"] for p in view["plans"]], ["rail"])
        self.assertTrue(any("No payment" in a["detail"] for a in view["actions"]))

    def test_stale_preference_cannot_be_approved(self):
        self.trip.disrupt_flight()
        reviewed_revision = self.trip.revision
        self.trip.set_preferences({"max_extra": 1000})
        with self.assertRaises(TripError) as ctx:
            self.trip.approve("coach", reviewed_revision)
        self.assertEqual(ctx.exception.code, 409)
        self.assertEqual(self.trip.cash_spent, 0)

    def test_stale_quote_even_if_still_feasible_requires_new_review(self):
        self.trip.disrupt_flight()
        reviewed_revision = self.trip.revision
        self.trip.set_preferences({"max_extra": 2600})
        with self.assertRaises(TripError) as ctx:
            self.trip.approve("coach", reviewed_revision)
        self.assertIn("changed since it was reviewed", str(ctx.exception))
        self.assertEqual(self.trip.cash_spent, 0)
        self.approve_current("coach")
        self.assertEqual(self.trip.snapshot()["phase"], "travel_secured")

    def test_missing_or_invalid_revision_is_never_approved(self):
        self.trip.disrupt_flight()
        for revision in (None, True, "1"):
            with self.subTest(revision=revision), self.assertRaises(TripError):
                self.trip.approve("coach", revision)
            self.assertEqual(self.trip.cash_spent, 0)

    def test_invalid_preferences_change_nothing(self):
        with self.assertRaises(TripError):
            self.trip.set_preferences({"max_extra": 1000, "step_free_only": "yes"})
        self.assertEqual(self.trip.preferences["max_extra"], 2500)
        self.assertFalse(self.trip.preferences["step_free_only"])

    def test_lowered_budget_does_not_undo_confirmed_travel(self):
        self.trip.disrupt_flight()
        self.approve_current("coach")
        self.trip.set_preferences({"max_extra": 500})
        self.trip.disrupt_hotel()
        view = self.trip.snapshot()
        self.assertEqual(view["journey"][1]["status"], "Demo confirmed")
        self.assertTrue(view["no_feasible"])
        self.assertEqual(view["gross_extra"], 1150)
        self.trip.set_preferences({"max_extra": 2500})
        self.assertEqual([p["id"] for p in self.trip.snapshot()["plans"]], ["royal-fern"])


if __name__ == "__main__":
    unittest.main()
