"""Contract tests for the optional provider adapter; no external API requests."""
import json
import os
import unittest
from unittest.mock import patch

import ai_bridge


class AIBridgeTests(unittest.TestCase):
    def test_disabled_without_server_key(self):
        with patch.dict(os.environ, {"TRIP_RESCUE_AI_API_KEY": "", "OPENAI_API_KEY": ""}):
            self.assertFalse(ai_bridge.enabled())
            with self.assertRaises(ai_bridge.AIUnavailable):
                ai_bridge._post("/chat/completions", b"{}", "application/json")

    def test_transcription_multipart_and_bounded_output(self):
        audio = b"\x1a\x45webm" + b"sample" * 30
        with patch.object(ai_bridge, "_post", return_value={"text": "  Bengaluru to Mysuru  "}) as provider:
            result = ai_bridge.transcribe(audio, "audio/webm;codecs=opus")
        self.assertEqual(result, "Bengaluru to Mysuru")
        path, payload, content_type = provider.call_args.args
        self.assertEqual(path, "/audio/transcriptions")
        self.assertIn("multipart/form-data; boundary=", content_type)
        self.assertIn(b'name="model"\r\n\r\ngpt-transcribe', payload)
        self.assertIn(b'filename="request.webm"', payload)
        self.assertIn(audio, payload)
        with self.assertRaises(ValueError):
            ai_bridge.transcribe(audio, "text/plain")
        with self.assertRaises(ValueError):
            ai_bridge.transcribe(b"tiny", "audio/webm")
        with patch.object(ai_bridge, "_post", return_value={"text": ""}):
            with self.assertRaises(ai_bridge.AIUnavailable):
                ai_bridge.transcribe(audio, "audio/webm")

    def test_model_receives_bounded_context_and_returns_structured_intent(self):
        state = {"phase": "flight_alert", "plans": [
            {"id": "coach", "title": "Airport coach", "price": 1150, "arrival_short": "00:15", "margin": "40 min", "hotel_margin": "30 min", "description": "synthetic"}
        ]}
        reply = {"actions": [{"type": "review_plan", "plan_id": "coach"}], "focus": "answer", "reply": "I can explain the coach."}
        with patch.object(ai_bridge, "_post", return_value={"choices": [{"message": {"content": json.dumps(reply)}}]}) as provider:
            answer = ai_bridge.interpret("Tell me about the coach", state, {"last_plan": None, "history": []})
        self.assertEqual(answer, reply)
        path, raw, content_type = provider.call_args.args
        self.assertEqual(path, "/chat/completions")
        self.assertEqual(content_type, "application/json")
        request = json.loads(raw)
        self.assertEqual(request["model"], "gpt-5.4-mini")
        self.assertEqual(request["response_format"], {"type": "json_object"})
        self.assertFalse(request["store"])
        self.assertIn("Only plan IDs that appear", request["messages"][0]["content"])
        with patch.object(ai_bridge, "_post", return_value={"choices": [{"message": {"content": "not json"}}]}):
            with self.assertRaises(ai_bridge.AIUnavailable):
                ai_bridge.interpret("Hello", state, {})


if __name__ == "__main__":
    unittest.main()
