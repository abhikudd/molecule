"""Trip Rescue demo engine.

All schedules, suppliers, inventory and confirmations in this module are synthetic.
The rules are deliberately deterministic so the demo can be audited and tested.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import uuid4

IST = timezone(timedelta(hours=5, minutes=30))


def at(iso: str) -> datetime:
    return datetime.fromisoformat(iso).replace(tzinfo=IST)


def clock(dt: datetime) -> str:
    return dt.strftime("%H:%M")


FLIGHT_ORIGINAL = at("2026-10-22T18:10")
FLIGHT_DELAYED = at("2026-10-22T19:35")
TRAIN_ORIGINAL = at("2026-10-22T20:35")
ORIGINAL_HOTEL_CUTOFF = at("2026-10-23T01:00")
GOAL = at("2026-10-23T08:00")

# Illustrative transfer assumptions, NOT live Bengaluru transit data or a claim
# that an airport metro connection is operating. Compare before rejecting the train.
ORIGINAL_TRAIN_TRANSFERS = [
    {"id": "road", "label": "Optimistic direct road transfer", "bags_exit_min": 35,
     "transfer_min": 45, "boarding_min": 15, "availability": "Illustrative estimate; traffic unverified"},
    {"id": "metro-link", "label": "Hypothetical metro-linked transfer", "bags_exit_min": 35,
     "transfer_min": 70, "boarding_min": 15, "availability": "Illustrative connection; airport service unverified"},
]

TRANSPORTS = [
    {
        "id": "coach",
        "name": "Airport coach",
        "title": "Airport coach · keep her room",
        "subtitle": "The smallest change that still gets her there.",
        "mode": "coach",
        "departure": at("2026-10-22T21:05"),
        "arrival": at("2026-10-23T00:15"),
        "boarding_after_flight_min": 50,  # 35 mins bags/exit + 15 mins boarding
        "hotel_transfer_min": 15,
        "fare": 1150,
        "origin": "Bengaluru Airport",
        "destination": "Mysuru coach stop",
        "source": "Sample Coach inventory",
        "capacity": 3,
        "accessible": False,  # unverified accessibility is not assumed to be safe
        "road": True,
        "keeps": 2,
    },
    {
        "id": "rail",
        "name": "Later train",
        "title": "Later train · 24-hour stay",
        "subtitle": "A wider transfer window and check-in any time.",
        "mode": "train",
        "departure": at("2026-10-22T22:40"),
        "arrival": at("2026-10-23T01:15"),
        "boarding_after_flight_min": 120,  # 35 mins bags + 70 mins station + 15 mins boarding
        "hotel_transfer_min": 12,
        "fare": 690,
        "origin": "Bengaluru City",
        "destination": "Mysuru Junction",
        "source": "Sample Rail inventory",
        "capacity": 2,
        "accessible": True,  # travel plus station transfer verified in the synthetic fixture
        "road": False,
        "keeps": 1,
    },
    {
        "id": "car",
        "name": "Private car",
        "title": "Private car · direct to hotel",
        "subtitle": "A direct option, but outside her current limit.",
        "mode": "car",
        "departure": at("2026-10-22T20:20"),
        "arrival": at("2026-10-22T23:55"),
        "boarding_after_flight_min": 45,
        "hotel_transfer_min": 0,
        "fare": 3900,
        "origin": "Bengaluru Airport",
        "destination": "The Tamarind House",
        "source": "Sample Car inventory",
        "capacity": 1,
        "accessible": False,
        "road": True,
        "keeps": 2,
    },
]

INITIAL_HOTEL = {
    "id": "tamarind",
    "name": "The Tamarind House",
    "detail": "Mysuru · check-in until 01:00",
    "cutoff": ORIGINAL_HOTEL_CUTOFF,
    "new_cost": 0,
    "source": "Sample Hotel record",
    "accessible": False,  # the original hotel's step-free route is unverified
}

ALTERNATE_HOTEL = {
    "id": "sandalwood",
    "name": "Sandalwood Stay",
    "detail": "Mysuru · reception open 24 hours",
    "cutoff": None,
    "new_cost": 1450,
    "source": "Sample Hotel inventory",
    "accessible": True,  # last-mile transfer and entrance verified in the synthetic fixture
}

HOTEL_RESCUES = [
    {
        "id": "royal-fern",
        "name": "Royal Fern House",
        "detail": "24-hour desk · near the morning venue",
        "new_cost": 1090,
        "travel_min": 18,
        "source": "Sample Hotel inventory",
        "capacity": 1,
        "accessible": True,  # last-mile route and entrance verified only in the demo
    },
    {
        "id": "blue-lotus",
        "name": "Blue Lotus Residence",
        "detail": "24-hour desk · step-free entrance",
        "new_cost": 1750,
        "travel_min": 22,
        "source": "Sample Hotel inventory",
        "capacity": 1,
        "accessible": True,  # last-mile route and entrance verified only in the demo
    },
]


class TripError(Exception):
    def __init__(self, message: str, code: int = 400):
        super().__init__(message)
        self.code = code


class TripEngine:
    """One isolated demo trip. Never represents a real reservation or payment."""

    def __init__(self) -> None:
        self.trip_id = uuid4().hex  # Internal generation guard for idempotent request replays after reset.
        self.phase = "ready"
        self.preferences: dict[str, Any] = {
            "max_extra": 2500,
            "avoid_overnight_road": False,
            "step_free_only": False,
        }
        self.events: list[dict[str, Any]] = [
            {"time": "16:05 IST", "title": "A connected trip is ready", "detail": "Three sample bookings, one arrival that matters.", "tone": "neutral"}
        ]
        self.actions: list[dict[str, Any]] = []
        self.current_transport: dict[str, Any] | None = None
        self.current_hotel: dict[str, Any] = deepcopy(INITIAL_HOTEL)
        self.cash_spent = 0
        self.confirmed_refunds = 0
        self.cancelled_hotel_id: str | None = None
        self.unavailable: set[str] = set()
        self.fail_next: str | None = None
        self.last_error: str | None = None
        self.revision = 0
        self.confirmation_serial = 317
        self.chosen: list[dict[str, Any]] = []

    @property
    def gross_extra(self) -> int:
        """Extra money actually paid, less only simulated *confirmed* refunds."""
        return self.cash_spent - self.confirmed_refunds

    def _event(self, title: str, detail: str, tone: str = "neutral", time: str = "19:37 IST") -> None:
        self.events.insert(0, {"time": time, "title": title, "detail": detail, "tone": tone})
        self.revision += 1

    def _action(self, title: str, detail: str, state: str) -> None:
        self.actions.insert(0, {"title": title, "detail": detail, "state": state})

    def set_preferences(self, values: dict[str, Any]) -> None:
        allowed = {"max_extra", "avoid_overnight_road", "step_free_only"}
        if not set(values).issubset(allowed):
            raise TripError("An unsupported preference was supplied.")
        if "max_extra" in values:
            value = values["max_extra"]
            if isinstance(value, bool) or not isinstance(value, int) or value < 500 or value > 8000:
                raise TripError("The extra-cash limit must be between ₹500 and ₹8,000.")
        for field in ("avoid_overnight_road", "step_free_only"):
            if field in values and not isinstance(values[field], bool):
                raise TripError("Preferences must be on or off.")
        # Validate every field before applying any: a rejected request changes nothing.
        self.preferences.update(values)
        self.last_error = None
        event_time = {
            "ready": "16:06 IST", "flight_alert": "19:38 IST", "travel_secured": "19:47 IST",
            "hotel_alert": "20:03 IST", "complete": "20:08 IST",
        }[self.phase]
        self._event("Preferences updated", "The full itinerary was checked again against her non-negotiables.", time=event_time)

    def disrupt_flight(self) -> None:
        if self.phase != "ready":
            raise TripError("The flight delay has already been replayed.")
        self.phase = "flight_alert"
        self._event(
            "Flight arrival moves to 19:35",
            "Both sample road and hypothetical metro-linked transfers miss the 20:35 train after bags and boarding; no live route was checked.",
            tone="danger",
            time="19:02 IST",
        )
        self._action("Connection flagged", "Original 20:35 train is still issued; no ticket has been cancelled.", "attention")

    def disrupt_hotel(self) -> None:
        if self.phase != "travel_secured":
            raise TripError("Confirm an alternative journey before replaying the hotel event.")
        self.phase = "hotel_alert"
        for change in self.chosen:
            if change["kind"] == "travel":
                change["status"] = "travel retained; first room later cancelled"
        self.cancelled_hotel_id = self.current_hotel["id"]
        self.current_hotel["cancelled"] = True
        # A past acknowledgement remains in the audit trail, but must never still
        # be labelled as an active confirmation after the supplier cancels it.
        for action in self.actions:
            if action["title"] in ("Replacement room confirmed · simulation", "Original hotel preserved"):
                action["title"] = "Earlier room confirmation · superseded"
                action["detail"] = (
                    f"{self.current_hotel['name']} was previously confirmed in this demo, "
                    "then the sample supplier cancelled it at 20:02. It is no longer a usable room."
                )
                action["state"] = "superseded"
                break
        self._event(
            f"{self.current_hotel['name']} cannot honour check-in",
            "The new travel leg remains confirmed in this demo. Only the night stay needs repairing.",
            tone="danger",
            time="20:02 IST",
        )
        if self.current_hotel["id"] == "sandalwood":
            # A deliberately explicit simulated supplier-confirmed refund; never a pending refund.
            self.confirmed_refunds += self.current_hotel["new_cost"]
            self._action(
                "Demo hotel reversal confirmed",
                f"₹{self.current_hotel['new_cost']:,} returned by the simulated supplier; reflected in spend.",
                "verified",
            )
        self._action(
            "Hotel cancelled by supplier · simulation",
            f"{self.current_hotel['name']} cannot honour check-in. No replacement room is confirmed yet.",
            "attention",
        )

    def mark_offer_sold_out(self, plan_id: str) -> None:
        if self.phase not in ("flight_alert", "hotel_alert"):
            raise TripError("Open a recovery option before simulating an offer change.")
        if not any(p["id"] == plan_id for p in self.available_plans()[0]):
            raise TripError("That option is no longer available.")
        self.fail_next = plan_id
        event_time = "20:04 IST" if self.phase == "hotel_alert" else "19:39 IST"
        self._event("Supplier quote changed", "This option will fail its final check. No booking has been made.", "warning", event_time)

    def transfer_checks(self) -> list[dict[str, Any]]:
        """Compare sample metro-linked and road paths before ruling out the original train."""
        checks = []
        for path in ORIGINAL_TRAIN_TRANSFERS:
            ready_to_board = FLIGHT_DELAYED + timedelta(
                minutes=path["bags_exit_min"] + path["transfer_min"] + path["boarding_min"]
            )
            slack = int((TRAIN_ORIGINAL - ready_to_board).total_seconds() // 60)
            checks.append({
                "id": path["id"], "label": path["label"],
                "bags_exit_min": path["bags_exit_min"], "transfer_min": path["transfer_min"],
                "boarding_min": path["boarding_min"], "ready_to_board": clock(ready_to_board),
                "slack_min": slack, "feasible": slack >= 0,
                "availability": path["availability"],
            })
        return checks

    def _first_candidates(self) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        valid: list[dict[str, Any]] = []
        rejected: list[dict[str, str]] = []
        for offer in TRANSPORTS:
            if offer["id"] == "rail":
                hotel = ALTERNATE_HOTEL
                stay_transfer = offer["hotel_transfer_min"]
            else:
                hotel = INITIAL_HOTEL
                stay_transfer = offer["hotel_transfer_min"]
            earliest_safe = FLIGHT_DELAYED + timedelta(minutes=offer["boarding_after_flight_min"])
            connection_margin = int((offer["departure"] - earliest_safe).total_seconds() // 60)
            hotel_arrival = offer["arrival"] + timedelta(minutes=stay_transfer)
            hotel_margin = (
                int((hotel["cutoff"] - hotel_arrival).total_seconds() // 60)
                if hotel["cutoff"] else None
            )
            total = offer["fare"] + hotel["new_cost"]
            problems = []
            if offer["id"] in self.unavailable:
                problems.append("Supplier reported no remaining seat or vehicle.")
            if offer["capacity"] < 1:
                problems.append("No space remains for this traveller.")
            if connection_margin < 0:
                problems.append(f"Needs {-connection_margin} more minutes to make the connection.")
            if hotel_margin is not None and hotel_margin < 0:
                problems.append(f"Hotel check-in would be {-hotel_margin} minutes too late.")
            if offer["road"] and self.preferences["avoid_overnight_road"]:
                problems.append("Blocked by the no-overnight-road rule.")
            if self.preferences["step_free_only"] and not offer["accessible"]:
                problems.append("Step-free access has not been verified for the travel and transfer.")
            if self.preferences["step_free_only"] and not hotel["accessible"]:
                problems.append("Step-free access has not been verified for the night stay.")
            if total + self.gross_extra > self.preferences["max_extra"]:
                problems.append(f"₹{total + self.gross_extra:,} exceeds the ₹{self.preferences['max_extra']:,} extra-cash limit.")
            if hotel_arrival > GOAL:
                problems.append("Cannot reach Mysuru before the 08:00 arrival goal.")
            if problems:
                rejected.append({"title": offer["title"], "reason": problems[0], "id": offer["id"]})
                continue
            risk = "Watch the final connection" if hotel_margin is not None else "More breathing room"
            valid.append({
                "id": offer["id"],
                "kind": "travel",
                "title": offer["title"],
                "subtitle": offer["subtitle"],
                "price": total,
                "total_cash": total + self.gross_extra,
                "arrival": f"{clock(offer['arrival'])} · Fri 23 Oct",
                "arrival_short": clock(offer["arrival"]),
                "hotel_arrival": f"{clock(hotel_arrival)} · Fri 23 Oct" if hotel_arrival.day == 23 else f"{clock(hotel_arrival)} · Thu 22 Oct",
                "margin": f"{connection_margin} min to board",
                "margin_minutes": connection_margin,
                "hotel_margin": f"{hotel_margin} min before check-in closes" if hotel_margin is not None else "24-hour check-in",
                "preserved": f"{offer['keeps']} of 3 original bookings",
                "keeps_count": offer["keeps"],
                "risk": risk,
                "mode": offer["mode"],
                "description": (
                    f"Keeps the original hotel and leaves a {connection_margin}-minute boarding margin. "
                    f"The hotel check-in still has a {hotel_margin}-minute cushion; keep an eye on the road journey."
                    if offer["id"] == "coach" else
                    f"A later train has a {connection_margin}-minute station boarding margin. "
                    "A 24-hour desk removes the original hotel's check-in risk."
                    if offer["id"] == "rail" else
                    "Direct to the existing hotel, but only when the increased budget is explicitly allowed."
                ),
                "steps": [
                    {"label": "Travel", "value": f"{offer['name']} · {clock(offer['departure'])}–{clock(offer['arrival'])}"},
                    {"label": "Night stay", "value": f"{hotel['name']} · {'keep booking' if hotel['new_cost'] == 0 else 'new booking'}"},
                    {"label": "Extra cash", "value": f"₹{offer['fare']:,} travel + ₹{hotel['new_cost']:,} stay"},
                ],
                "source": (
                    f"{offer['source']} + {hotel['source']}"
                    + (" · step-free travel, transfer and stay verified in demo fixture"
                       if self.preferences["step_free_only"] else "")
                ),
                "checked_at": "19:37 IST · synthetic",
                "offer": offer,
                "hotel": hotel,
                "hotel_arrival_dt": hotel_arrival,
            })
        # Display the smallest-change viable plan first, then the alternatives.
        valid.sort(key=lambda p: (-p["keeps_count"], p["price"], -p["margin_minutes"]))
        for i, plan in enumerate(valid):
            plan["recommended"] = i == 0
            plan["badge"] = "BEST FIT" if i == 0 else "ALTERNATIVE"
        # The fastest *illustrative* transfer still misses; never pretend these are live routes.
        checks = {path["id"]: path for path in self.transfer_checks()}
        road, metro = checks["road"], checks["metro-link"]
        rejected.insert(0, {
            "title": "Keep the original 20:35 train",
            "reason": (
                f"Even an optimistic {road['transfer_min']}-min road transfer is ready to board at "
                f"{road['ready_to_board']} ({-road['slack_min']} min late); the hypothetical metro-linked "
                f"path is ready at {metro['ready_to_board']} ({-metro['slack_min']} min late). "
                "Bags and boarding included; neither transfer is live-checked."
            ),
            "id": "original-train",
        })
        return valid, rejected

    def _hotel_candidates(self) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        valid: list[dict[str, Any]] = []
        rejected: list[dict[str, str]] = []
        assert self.current_transport is not None
        for hotel in HOTEL_RESCUES:
            total = self.gross_extra + hotel["new_cost"]
            problems = []
            if hotel["id"] in self.unavailable:
                problems.append("The simulated supplier reports this room sold out.")
            if hotel["capacity"] < 1:
                problems.append("No room is available for this traveller.")
            if self.preferences["step_free_only"] and not hotel["accessible"]:
                problems.append("Step-free access has not been verified for this night stay and transfer.")
            if self.preferences["step_free_only"] and not self.current_transport["accessible"]:
                problems.append("The confirmed travel leg lacks verified step-free access; hotel-only repair cannot fix it.")
            if self.preferences["avoid_overnight_road"] and self.current_transport["road"]:
                problems.append("The confirmed road leg conflicts with the no-overnight-road rule; hotel-only repair cannot fix it.")
            if total > self.preferences["max_extra"]:
                problems.append(f"₹{total:,} exceeds the ₹{self.preferences['max_extra']:,} extra-cash limit.")
            checkin = self.current_transport["arrival"] + timedelta(minutes=hotel["travel_min"])
            if checkin > GOAL:
                problems.append("Cannot reach the 08:00 arrival goal.")
            if problems:
                rejected.append({"title": hotel["name"], "reason": problems[0], "id": hotel["id"]})
                continue
            valid.append({
                "id": hotel["id"],
                "kind": "hotel",
                "title": hotel["name"],
                "subtitle": hotel["detail"],
                "price": hotel["new_cost"],
                "total_cash": total,
                "arrival": f"{clock(checkin)} · Fri 23 Oct",
                "arrival_short": clock(checkin),
                "hotel_arrival": f"{clock(checkin)} · Fri 23 Oct",
                "margin": "24-hour check-in",
                "margin_minutes": 999,
                "hotel_margin": "24-hour reception",
                "preserved": "Confirmed travel leg stays exactly as it is",
                "keeps_count": 1,
                "risk": "Travel is already secured",
                "mode": "hotel",
                "description": (
                    "Only the cancelled stay changes. The confirmed journey is preserved, "
                    "and the new room has a staffed desk through the night."
                ),
                "steps": [
                    {"label": "Travel", "value": f"Keep confirmed {self.current_transport['name'].lower()}"},
                    {"label": "Night stay", "value": f"Book {hotel['name']}"},
                    {"label": "Extra cash now", "value": f"₹{hotel['new_cost']:,} · total ₹{total:,}"},
                ],
                "source": hotel["source"] + (
                    " · step-free last-mile transfer and entrance verified in demo fixture"
                    if self.preferences["step_free_only"] else ""
                ),
                "checked_at": "20:03 IST · synthetic",
                "hotel": hotel,
                "hotel_arrival_dt": checkin,
            })
        valid.sort(key=lambda p: p["price"])
        for i, plan in enumerate(valid):
            plan["recommended"] = i == 0
            plan["badge"] = "BEST FIT" if i == 0 else "ALTERNATIVE"
        return valid, rejected

    def available_plans(self) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
        if self.phase == "flight_alert":
            return self._first_candidates()
        if self.phase == "hotel_alert":
            return self._hotel_candidates()
        return [], []

    def approve(self, plan_id: str, expected_revision: int) -> str:
        if self.phase not in ("flight_alert", "hotel_alert"):
            raise TripError("There is no unapproved recovery action right now.")
        failure_time = "20:05 IST" if self.phase == "hotel_alert" else "19:40 IST"
        plans, _ = self.available_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
        if plan is None:
            self.last_error = "This option no longer meets the trip's constraints. Nothing was booked or cancelled."
            self._event("Infeasible quote stopped", self.last_error, "warning", failure_time)
            self._action("Infeasible plan declined", "No new booking, payment or cancellation occurred.", "attention")
            raise TripError(self.last_error, 409)
        if self.fail_next == plan_id:
            self.fail_next = None
            self.unavailable.add(plan_id)
            self.last_error = "The supplier reported this offer sold out during final recheck. No replacement was booked and no original booking was cancelled."
            self._event("Safe stop: offer sold out", self.last_error, "danger", failure_time)
            self._action("Revalidation failed safely", "No payment, no replacement and no original cancellation in this demo.", "attention")
            raise TripError(self.last_error, 409)
        if type(expected_revision) is not int or expected_revision != self.revision:
            self.last_error = (
                "This quote changed since it was reviewed. Open the current plan again. "
                "Nothing was booked, paid or cancelled."
            )
            self._event("Outdated quote safely stopped", self.last_error, "warning", failure_time)
            self._action("Outdated quote declined", "A new review is required before any simulated action.", "attention")
            raise TripError(self.last_error, 409)
        # Plans are generated and fully checked on the server on this exact request.
        self.confirmation_serial += 1
        self.last_error = None
        if self.phase == "flight_alert":
            offer = plan["offer"]
            hotel = plan["hotel"]
            self.current_transport = offer
            self.current_hotel = deepcopy(hotel)
            self.current_hotel["expected_checkin"] = clock(plan["hotel_arrival_dt"])
            self.cash_spent += plan["price"]
            self.phase = "travel_secured"
            self.chosen.append({"kind": "travel", "id": plan_id, "title": plan["title"], "price": plan["price"], "status": "active"})
            is_cab = plan_id == "car"
            code = f"DEMO-{'CAB' if is_cab else 'TR'}-{self.confirmation_serial}"
            self._event("Ananya has a way to Mysuru", f"{plan['title']} was confirmed by the simulated supplier. She is still on track for 08:00.", "success", "19:42 IST")
            self._action("Replacement travel confirmed · simulation", f"{offer['name']} · confirmation {code}. No real {'cab or driver was assigned' if is_cab else 'ticket was issued'}.", "verified")
            if hotel["new_cost"]:
                self._action("Replacement room confirmed · simulation", f"{hotel['name']} · DEMO-HT-{self.confirmation_serial}. No real room was reserved.", "verified")
                self._action("Original hotel cancellation", "Still needs traveller/provider action; not marked cancelled.", "pending")
            else:
                self._action("Original hotel preserved", f"{hotel['name']} remains confirmed; expected check-in {plan['hotel_arrival']}.", "verified")
            self._action("Original train refund", "Request prepared for the traveller; refund not assumed or counted.", "pending")
        else:
            hotel = plan["hotel"]
            self.current_hotel = {
                "id": hotel["id"],
                "name": hotel["name"],
                "detail": hotel["detail"],
                "cutoff": None,
                "new_cost": hotel["new_cost"],
                "source": hotel["source"],
                "accessible": hotel["accessible"],
                "expected_checkin": clock(plan["hotel_arrival_dt"]),
            }
            self.cash_spent += hotel["new_cost"]
            self.phase = "complete"
            self.chosen.append({"kind": "hotel", "id": plan_id, "title": plan["title"], "price": plan["price"], "status": "active"})
            code = f"DEMO-HT-{self.confirmation_serial}"
            for action in self.actions:
                if action["title"] == "Hotel cancelled by supplier · simulation":
                    action["detail"] = (
                        "The earlier stay was cancelled by the sample supplier; "
                        "a separately confirmed replacement now exists."
                    )
                    action["state"] = "superseded"
                    break
            self._event("The final missing piece is in place", f"{hotel['name']} confirmed in the simulator. The existing travel booking stayed untouched.", "success", "20:06 IST")
            self._action("New room confirmed · simulation", f"{hotel['name']} · confirmation {code}. No real room was reserved.", "verified")
            self._action("Travel booking preserved", "Previously confirmed replacement remains unchanged.", "verified")
        return "Final check passed. The selected replacement is confirmed in this simulation."

    def public_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        """Remove private datetime/template objects before publishing as JSON."""
        keys = (
            "id", "kind", "title", "subtitle", "price", "total_cash", "arrival", "arrival_short",
            "hotel_arrival", "margin", "hotel_margin", "preserved", "risk", "mode", "description",
            "steps", "source", "checked_at", "recommended", "badge",
        )
        return {key: plan[key] for key in keys}

    def _journey(self) -> list[dict[str, str]]:
        if self.phase == "ready":
            flight_status, train_status, hotel_status = "Confirmed", "Confirmed", "Confirmed"
            flight_tone = train_tone = hotel_tone = "success"
        elif self.phase == "flight_alert":
            flight_status, train_status, hotel_status = "+85 min", "Connection missed", "Check-in at risk"
            flight_tone, train_tone, hotel_tone = "warning", "danger", "warning"
        elif self.phase in ("travel_secured", "hotel_alert", "complete"):
            flight_status = "+85 min"
            flight_tone = "warning"
            train_status, train_tone = "Demo confirmed", "success"
            hotel_status, hotel_tone = ("Stay cancelled", "danger") if self.phase == "hotel_alert" else ("Demo confirmed" if self.current_hotel["id"] != "tamarind" else "Confirmed", "success")
        else:
            raise AssertionError("unknown phase")
        flight = {
            "id": "flight", "icon": "plane", "eyebrow": "LEG 01 · FLIGHT", "title": "Delhi → Bengaluru",
            "provider": "Demo Air · FL 204", "time": "18:10 arrival" if self.phase == "ready" else "19:35 expected arrival",
            "status": flight_status, "tone": flight_tone,
            "detail": "Original arrival 18:10" if self.phase != "ready" else "Confirmed booking · sample itinerary",
        }
        if self.current_transport is None:
            travel = {
                "id": "train", "icon": "train", "eyebrow": "LEG 02 · TRAIN", "title": "Bengaluru → Mysuru",
                "provider": "Sample Rail · original ticket", "time": "20:35 departure",
                "status": train_status, "tone": train_tone,
                "detail": "Ticket remains issued; no cancellation" if self.phase != "ready" else "Board at Bengaluru City",
            }
        else:
            travel = {
                "id": "replacement", "icon": "car" if self.current_transport["road"] else "train",
                "eyebrow": f"LEG 02 · {self.current_transport['name'].upper()}",
                "title": f"{self.current_transport['origin']} → Mysuru",
                "provider": self.current_transport["source"],
                "time": f"{clock(self.current_transport['departure'])} → {clock(self.current_transport['arrival'])}",
                "status": train_status, "tone": train_tone,
                "detail": "New confirmation is simulated · old train not cancelled",
            }
        hotel = {
            "id": "hotel", "icon": "hotel", "eyebrow": "LEG 03 · NIGHT STAY", "title": self.current_hotel["name"],
            "provider": self.current_hotel["detail"],
            "time": (
                f"{self.current_hotel['expected_checkin']} expected check-in"
                if self.phase in ("travel_secured", "complete") else
                "Stay cancelled" if self.phase == "hotel_alert" else
                "01:00 check-in cutoff" if self.current_hotel["id"] == "tamarind" else "24-hour check-in"
            ),
            "status": hotel_status, "tone": hotel_tone,
            "detail": "New room needed" if self.phase == "hotel_alert" else "The night before the birthday",
        }
        return [flight, travel, hotel]

    def _impact(self) -> dict[str, Any]:
        if self.phase == "ready":
            return {
                "tone": "calm", "eyebrow": "TRIP STATUS", "title": "Everything is still connected.",
                "description": "A delay on one leg can change the entire journey. Replay it to see how Trip Rescue responds.",
                "chips": ["Flight on schedule", "Train connection intact", "Hotel check-in safe"],
            }
        if self.phase == "flight_alert":
            return {
                "tone": "danger", "eyebrow": "DISRUPTION DETECTED", "title": "One delay. Three things at stake.",
                "description": "An 85-minute flight delay breaks the train connection. The hotel check-in needs a new arrival plan.",
                "chips": ["Flight +85 min", "Original train missed", "Hotel check-in at risk"],
            }
        if self.phase == "travel_secured":
            return {
                "tone": "success", "eyebrow": "A WAY FORWARD", "title": "Ananya is still on her way.",
                "description": "The replacement is confirmed in the simulator. Existing bookings were not silently cancelled.",
                "chips": ["Replacement confirmed in demo", "Original train still issued", "Arrival before 08:00"],
            }
        if self.phase == "hotel_alert":
            return {
                "tone": "danger", "eyebrow": "A SECOND CHANGE", "title": "The room fell through. Her journey didn't.",
                "description": "Her confirmed travel leg is kept. The agent is repairing only the night stay.",
                "chips": ["Travel remains confirmed in demo", "Hotel cancelled", "New room needed"],
            }
        return {
            "tone": "success", "eyebrow": "RECOVERY COMPLETE · SIMULATION", "title": "She can be there for the moment.",
            "description": "Travel and night stay are confirmed in this simulation. The original train refund is still a traveller action.",
            "chips": ["Travel confirmed in demo", "Room confirmed in demo", "Arrival before 08:00"],
        }

    def _active_conflicts(self) -> list[str]:
        """Warn when a new preference conflicts with an already confirmed demo leg."""
        conflicts = []
        if self.current_transport:
            if self.preferences["avoid_overnight_road"] and self.current_transport["road"]:
                conflicts.append("Confirmed road travel conflicts with the new no-road rule.")
            if self.preferences["step_free_only"] and not self.current_transport["accessible"]:
                conflicts.append("Confirmed travel lacks verified step-free access.")
        if (self.phase in ("travel_secured", "complete") and self.preferences["step_free_only"]
                and not self.current_hotel.get("accessible", False)):
            conflicts.append("Confirmed stay lacks verified step-free access.")
        return conflicts

    def snapshot(self) -> dict[str, Any]:
        plans, rejected = self.available_plans()
        intro = {
            "ready": "Ready to protect the journey",
            "flight_alert": "Recovery choices ready",
            "travel_secured": "Travel route secured in demo",
            "hotel_alert": "Night-stay recovery needed",
            "complete": "Recovery complete in demo",
        }[self.phase]
        total = self.gross_extra
        return {
            "phase": self.phase,
            "phase_label": intro,
            "revision": self.revision,
            "preferences": deepcopy(self.preferences),
            "active_conflicts": self._active_conflicts(),
            "journey": self._journey(),
            "impact": self._impact(),
            "plans": [self.public_plan(p) for p in plans],
            "rejected": rejected,
            "transfer_checks": self.transfer_checks(),
            "no_feasible": self.phase in ("flight_alert", "hotel_alert") and not plans,
            "events": deepcopy(self.events[:7]),
            "actions": deepcopy(self.actions),
            "gross_extra": total,
            "remaining": self.preferences["max_extra"] - total,
            "refund_confirmed": self.confirmed_refunds,
            "last_error": self.last_error,
            "pending_fail_plan": self.fail_next,
            "chosen": deepcopy(self.chosen),
            "arrival_goal": "Fri, 23 Oct · 08:00",
            "arrival_current": clock(self.current_transport["arrival"]) if self.current_transport else None,
            "sample_profile": {"traveller": "Ananya · fictional", "details_ready": True,
                               "vault_note": "Existing trip details are prefilled in this sample. No Aadhaar/PAN numbers or real payment data are stored or sent."},
            "demo_notice": "Illustrative scenario. All supplier feeds, prices, availability and confirmations are simulated.",
        }
