"""Fictional booking-app gateway for one-tap Trip Rescue demonstrations.

This adapter NEVER contacts a ticketing, hotel, cab, payment or identity service.
Production adapters must implement quote/revalidate/commit/verify using authorised
supplier contracts; the HTTP handler must only call them after explicit approval.
"""
from __future__ import annotations

from typing import Any

from engine import TripError, clock


class VirtualBookingGateway:
    """Translate one complete recovery plan into transparent demo-app steps."""

    @staticmethod
    def quote(plan: dict[str, Any]) -> dict[str, Any]:
        components: list[dict[str, Any]] = []
        if plan["kind"] == "hotel":
            components.extend([
                {"kind": "travel", "app": "Existing demo itinerary", "item": "Keep the confirmed travel leg", "price": 0,
                 "action": "preserve"},
                {"kind": "room", "app": "Virtual Stay App", "item": plan["hotel"]["name"],
                 "price": plan["hotel"]["new_cost"], "action": "reserve"},
            ])
        else:
            offer, stay = plan["offer"], plan["hotel"]
            app = {"coach": "Virtual Coach App", "rail": "Virtual Rail App", "car": "Virtual Cab App"}[plan["id"]]
            kind = "cab" if plan["id"] == "car" else "ticket"
            item = (f"{offer['name']} · {clock(offer['departure'])} departure"
                    if kind == "ticket" else f"Private cab · airport pickup {clock(offer['departure'])}")
            components.append({"kind": kind, "app": app, "item": item,
                               "price": offer["fare"], "action": "reserve"})
            components.append({"kind": "room", "app": "Virtual Stay App" if stay["new_cost"] else "Existing demo itinerary",
                               "item": stay["name"], "price": stay["new_cost"],
                               "action": "reserve" if stay["new_cost"] else "preserve"})
        if sum(c["price"] for c in components) != plan["price"]:
            raise TripError("The sample app components do not match the quoted total. Nothing changed.", 409)
        return {"plan_id": plan["id"], "plan_title": plan["title"], "price": plan["price"],
                "total_cash": plan["total_cash"], "arrival": plan["arrival_short"],
                "checked_at": plan["checked_at"], "currency": "INR", "components": components,
                "simulation": True, "live_availability": False}

    def book(self, engine: Any, plan_id: str, revision: int, price: int) -> tuple[str, dict[str, Any]]:
        """Atomic *virtual* handoff after consent was checked by the caller.

        A real adapter cannot use this all-or-nothing shortcut: it must quote,
        authorise, commit and verify each supplier operation, track partial
        results, and never cancel an original booking by inference.
        """
        plan = next((p for p in engine.available_plans()[0] if p["id"] == plan_id), None)
        if plan is None or type(price) is not int or price != plan["price"]:
            raise TripError("The selected price or option changed. Nothing was booked; review the current choices.", 409)
        quote = self.quote(plan)
        message = engine.approve(plan_id, revision)  # Rechecks revision, spend, feasibility and sample inventory.
        return message, self.receipt(quote, engine.confirmation_serial)

    @staticmethod
    def receipt(quote: dict[str, Any], serial: int) -> dict[str, Any]:
        """Report only steps the deterministic engine already confirmed in the simulator."""
        steps = []
        for component in quote["components"]:
            kind = component["kind"]
            action = component["action"]
            if action == "preserve":
                reference = None
                status = "preserved in sample itinerary"
            else:
                prefix = "CAB" if kind == "cab" else "TR" if kind == "ticket" else "HT"
                reference = f"DEMO-{prefix}-{serial}"
                status = "confirmed in simulation"
            steps.append({"kind": kind, "app": component["app"], "item": component["item"],
                          "price": component["price"], "reference": reference, "status": status,
                          "real_booking": False})
        return {"simulation": True, "live_booking": False, "plan_id": quote["plan_id"],
                "plan_title": quote["plan_title"], "extra_price": quote["price"],
                "total_cash": quote["total_cash"], "currency": "INR",
                "source_checked_at": quote["checked_at"], "steps": steps,
                "profile": "Prefilled fictional traveller details used; no real identity documents transmitted.",
                "notice": "Virtual booking apps only. No real ticket, cab, room, payment or driver was obtained."}
