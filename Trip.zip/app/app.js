/* Trip Rescue — one calm conversation over a server-validated fictional trip. */
const $ = (id) => document.getElementById(id);
const money = (n) => `₹${Number(n).toLocaleString('en-IN')}`;
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const sessionKey = 'trip-rescue-demo-session';
const bookingKey = 'trip-rescue-pending-virtual-booking';
let bookingIntent = null;
try { bookingIntent = JSON.parse(sessionStorage.getItem(bookingKey) || 'null'); } catch { sessionStorage.removeItem(bookingKey); }
let session = sessionStorage.getItem(sessionKey);
if (!session) {
  bookingIntent = null;
  sessionStorage.removeItem(bookingKey);
  session = (globalThis.crypto?.randomUUID?.() || `demo-${Date.now()}-${Math.floor(Math.random() * 100000)}`).replace(/[^a-zA-Z0-9_-]/g, '');
  sessionStorage.setItem(sessionKey, session);
}
const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const canSpeak = Boolean(window.speechSynthesis && window.SpeechSynthesisUtterance);
const audioMime = ['audio/webm;codecs=opus','audio/webm','audio/mp4'].find((type) => window.MediaRecorder?.isTypeSupported?.(type));
const canRecord = Boolean(navigator.mediaDevices?.getUserMedia && window.MediaRecorder && audioMime);
let state = null;
let pending = null;
let suggestions = [];
let capabilities = {ai_enabled:false, mode:'guided'};
let busy = false;
let micState = 'idle';
let listening = null;
let recording = null;
let activeConversation = false;
let micStarting = false;
let soundOn = canSpeak;
let speechSeq = 0;
let suppressNextSpeech = false;
let speechTimer = null;
let rearmTimer = null;
let toastTimer = null;
const log = $('conversationLog');
const scroll = $('conversationScroll');

function toast(text) {
  $('toast').textContent = text;
  $('toast').classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('show'), 4600);
}

function addMessage(who, text) {
  const node = document.createElement('div');
  node.className = `message ${who === 'user' ? 'user-msg' : 'assistant-msg'}`;
  node.textContent = text;
  log.append(node);
  while (log.children.length > 14) log.firstElementChild.remove();
  scrollToBottom();
  return node;
}
function scrollToBottom() {
  requestAnimationFrame(() => {
    const assistant = document.querySelector('.assistant');
    if (assistant.classList.contains('has-receipt') && innerWidth <= 650) {
      $('bookingMount').scrollIntoView({block:'nearest', behavior:'smooth'});
    } else if (innerWidth <= 650 && log.querySelector('.user-msg')) {
      log.lastElementChild?.scrollIntoView({block:'nearest', behavior:'smooth'});
    } else scroll.scrollTop = scroll.scrollHeight;
  });
}
function thinking() {
  const node = addMessage('assistant', 'One moment…');
  node.classList.add('thinking');
  return node;
}

function setMicState(next, extra = '') {
  micState = next;
  const label = $('micLabel');
  const hint = $('micHint');
  const button = $('micButton');
  button.classList.toggle('listening', next === 'listening');
  const view = {
    idle:['Tap to speak','Speak naturally. Pause to send, or tap again.','Start speaking'],
    starting:['Opening microphone…','Your browser may ask for permission.','Opening microphone'],
    listening:['Listening…','Pause to send automatically, or tap to finish.','Finish speaking'],
    thinking:['Checking your trip…','I’ll reply as soon as I have a safe answer.','Working on request'],
    speaking:['Speaking…','Tap the mic to interrupt and ask a follow-up.','Interrupt reply and speak'],
  }[next];
  label.textContent = view[0];
  hint.textContent = extra || view[1];
  button.setAttribute('aria-label', view[2]);
  button.disabled = next === 'starting' || next === 'thinking' || (!Recognition && !(capabilities.ai_enabled && canRecord));
  if (next === 'idle' && button.disabled) {
    hint.textContent = 'Voice input is unavailable here. Type or tap a suggestion.';
    button.setAttribute('aria-label', 'Voice input unavailable');
  }
  $('micMode').textContent = next === 'idle' ? (capabilities.ai_enabled ? (canRecord ? 'Cloud voice' : Recognition ? 'Browser voice · AI text' : 'Text only') : 'Guided mode') : next === 'listening' ? 'MIC ON' : next === 'thinking' ? 'CHECKING' : next === 'speaking' ? 'VOICE ON' : '';
  $('endConversation').hidden = !activeConversation;
}

function cancelSpeech() {
  speechSeq++;
  clearTimeout(speechTimer);
  if (canSpeak) try { window.speechSynthesis.cancel(); } catch { /* Speech is optional. */ }
}
function afterSpeech(seq) {
  if (seq !== speechSeq) return;
  clearTimeout(speechTimer);
  setMicState('idle');
  if (activeConversation && $('autoListen').checked && !document.hidden && !busy) {
    clearTimeout(rearmTimer);
    rearmTimer = setTimeout(() => { if (activeConversation && micState === 'idle') void startMic(); }, 340);
  } else {
    activeConversation = false;
    $('endConversation').hidden = true;
  }
}
function speak(text) {
  cancelSpeech();
  const seq = speechSeq;
  if (!soundOn || !canSpeak) { setTimeout(() => afterSpeech(seq), 180); return; }
  try {
    const spoken = text.replace(/₹\s*([\d,]+)/g, (_, number) => `${number} rupees`);
    const utterance = new SpeechSynthesisUtterance(spoken);
    utterance.lang = 'en-IN';
    utterance.rate = 1.08;
    const voices = window.speechSynthesis.getVoices();
    utterance.voice = voices.find((v) => v.lang.toLowerCase() === 'en-in') || voices.find((v) => v.lang.toLowerCase().startsWith('en-')) || null;
    utterance.onend = () => afterSpeech(seq);
    utterance.onerror = () => afterSpeech(seq);
    setMicState('speaking');
    window.speechSynthesis.speak(utterance);
    // Some embedded browsers never fire onend. Don't leave the mic UI stuck.
    speechTimer = setTimeout(() => afterSpeech(seq), Math.min(14500, Math.max(3300, spoken.length * 75)));
  } catch { afterSpeech(seq); }
}

function updateMode() {
  const badge = $('modeBadge');
  badge.textContent = capabilities.ai_enabled ? (canRecord ? 'AI VOICE READY' : 'AI TEXT READY') : 'GUIDED DEMO';
  badge.classList.toggle('ai', capabilities.ai_enabled);
  if (capabilities.ai_enabled && canRecord) {
    $('privacyText').textContent = 'Cloud voice: after you tap, audio goes to the configured provider; a redacted transcript and demo context inform the AI. No ID numbers or real bookings.';
  } else if (capabilities.ai_enabled && Recognition) {
    $('privacyText').textContent = 'Browser speech may process audio externally. Its redacted transcript goes to the configured AI provider. You can always type. No ID numbers.';
  } else if (capabilities.ai_enabled) {
    $('privacyText').textContent = 'Voice input is unavailable here. Typed messages use the configured AI service; no ID numbers or real bookings.';
  } else {
    $('privacyText').textContent = 'Guided browser speech may process audio externally. Never share ID numbers. Booking apps here are virtual; add a server AI key for open conversation.';
  }
  if (!canSpeak) {
    $('soundButton').disabled = true;
    $('soundButton').title = 'Spoken replies unavailable in this browser';
  }
  setMicState('idle');
}

function renderStatus() {
  const impact = state.impact;
  const mount = $('statusMount');
  const headings = {ready:'Just tell me what happened.', flight_alert:'Let’s find a way forward.',
    travel_secured:'A way forward, together.', hotel_alert:'Let’s save the stay.', complete:'The trip is back on track.'};
  $('assistantTitle').textContent = headings[state.phase] || headings.ready;
  mount.className = `status-card ${impact.tone || 'calm'}`;
  mount.innerHTML = `<span class="status-dot" aria-hidden="true"></span><div><small>THE TRIP RIGHT NOW · ${escapeHTML(state.phase_label)}</small><strong>${escapeHTML(impact.title)}</strong></div><span class="status-goal">Goal · 08:00</span>`;
}
function renderWelcome() {
  const mount = $('welcomeMount');
  const show = state.phase === 'ready' && !log.querySelector('.user-msg');
  document.querySelector('.assistant').classList.toggle('has-welcome', show);
  if (!show) { mount.replaceChildren(); return; }
  mount.innerHTML = `<div class="welcome-card"><span class="welcome-asterisk" aria-hidden="true">✳</span><p class="welcome-kicker">A CALMER WAY THROUGH</p><h3>One conversation for the whole journey.</h3><p>Tell me what changed. I’ll check the connections, show the safe choices and ask before any virtual booking.</p><div class="welcome-route"><span>FLIGHT</span><i aria-hidden="true"></i><span>ONWARD TRAVEL</span><i aria-hidden="true"></i><span>STAY</span></div></div>`;
}
function renderOptions() {
  const mount = $('optionMount');
  if (!['flight_alert','hotel_alert'].includes(state.phase)) { mount.replaceChildren(); return; }
  const count = state.plans.length;
  const heading = `<div class="options-heading"><div><span class="options-kicker">YOUR RECOVERY OPTIONS · ${count} ${count === 1 ? 'CHOICE' : 'CHOICES'}</span><strong>${count ? 'Choose what feels right.' : 'No safe option fits yet.'}</strong></div><span class="options-demo">SAMPLE PRICES</span></div>`;
  if (!count) {
    mount.innerHTML = heading + '<div class="empty-option"><strong>Let’s pause rather than guess.</strong><p>No option meets every limit right now. You can change a rule, stay nearby or ask for human help.</p><button type="button" data-open-limits>Review my limits ↗</button></div>';
    return;
  }
  mount.innerHTML = heading + state.plans.map((p, index) => `<article class="option-card"><div class="option-top"><span class="option-tag">${p.recommended ? 'BEST FIT · ' : ''}${escapeHTML(p.kind === 'hotel' ? 'NIGHT STAY' : p.id === 'car' ? 'CAB' : p.mode)}</span><span class="option-index" aria-hidden="true">0${index + 1}</span></div><h3>${escapeHTML(p.title)}</h3><p class="option-subtitle">${escapeHTML(p.subtitle)}</p><div class="option-facts"><div><small>EXTRA CASH</small><strong>${money(p.price)}</strong></div><div><small>ARRIVE</small><strong>${escapeHTML(p.arrival_short)}</strong></div></div><p class="option-meta">${escapeHTML(p.margin)} <span aria-hidden="true">·</span> ${escapeHTML(p.hotel_margin)}</p><p class="option-preserved">${escapeHTML(p.kind === 'hotel' ? 'Confirmed travel stays untouched' : `${p.preserved} kept`)}</p><div class="option-actions"><button class="option-choose" type="button" data-plan-book="${escapeHTML(p.id)}" aria-label="Approve ${escapeHTML(p.title)} for ${money(p.price)} extra and virtually book all needed parts">Approve &amp; book · ${money(p.price)}</button><button class="option-ask" type="button" data-plan-review="${escapeHTML(p.id)}">Details</button></div><p class="option-fineprint">Virtual only · ${escapeHTML(p.checked_at)} · No real payment</p></article>`).join('');
}
function renderPending() {
  const mount = $('confirmationMount');
  if (!pending) { mount.replaceChildren(); return; }
  if (pending.kind === 'reset') {
    mount.innerHTML = '<div class="confirmation-card"><div><strong>Restart the sample trip?</strong><small>This clears the demo progress.</small></div><button type="button" data-confirm="reset">Confirm</button><button type="button" class="reject-button" data-confirm="cancel">Keep trip</button></div>';
  } else {
    mount.innerHTML = `<div class="confirmation-card"><div><strong>${escapeHTML(pending.title)} · ${money(pending.price)} extra</strong><small>Shall I book the required parts using the saved sample details? Final demo check; no real purchase.</small></div><button type="button" data-confirm="plan">Approve &amp; book in demo</button><button type="button" class="reject-button" data-confirm="cancel">Not now</button></div>`;
  }
}
function renderBooking(booking) {
  const mount = $('bookingMount');
  const panel = document.querySelector('.assistant');
  if (!booking?.simulation || booking.live_booking) {
    mount.replaceChildren();
    panel.classList.remove('has-receipt');
    return;
  }
  const steps = booking.steps.map((step) => `<li><div><strong>${escapeHTML(step.app)}</strong><span>${escapeHTML(step.item)}</span></div><div class="booking-step-end"><b>${step.price ? money(step.price) : 'Kept'}</b><small>${step.reference ? `Demo ref ${escapeHTML(step.reference)}` : escapeHTML(step.status)}</small></div></li>`).join('');
  mount.innerHTML = `<section class="booking-card" aria-label="Virtual booking result"><span class="booking-kicker">VIRTUAL BOOKING APPS · NO REAL PURCHASE</span><h3>${escapeHTML(booking.plan_title)} <span>${money(booking.extra_price)} extra</span></h3><p>One approval handled the required demo steps. ${escapeHTML(booking.profile)}</p><ol>${steps}</ol><small class="booking-notice">Sample quote: ${escapeHTML(booking.source_checked_at)}. ${escapeHTML(booking.notice)}</small></section>`;
  panel.classList.add('has-receipt');
}
function renderSuggestions() {
  const mount = $('suggestions');
  mount.replaceChildren();
  for (const text of suggestions.slice(0, 3)) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = text;
    button.addEventListener('click', () => void sendText(text));
    mount.append(button);
  }
}
function renderOverview() {
  const icons = {plane:'✈', train:'▤', car:'↗', hotel:'⌂'};
  const names = ['FLIGHT', 'ONWARD TRAVEL', 'NIGHT STAY'];
  $('overviewMount').innerHTML = state.journey.map((leg, index) => {
    const tone = ['success','warning','danger'].includes(leg.tone) ? leg.tone : 'neutral';
    return `<li class="overview-leg ${tone}"><div class="overview-leg-top"><span class="overview-icon" aria-hidden="true">${icons[leg.icon] || '·'}</span><span class="overview-number">0${index + 1} / ${names[index]}</span></div><strong>${escapeHTML(leg.title)}</strong><span class="overview-time">${escapeHTML(leg.time)}</span><span class="overview-state ${tone}">${escapeHTML(leg.status)}</span></li>`;
  }).join('');
  const cap = state.preferences.max_extra;
  const spent = state.gross_extra;
  $('overviewGoal').textContent = state.arrival_goal;
  $('overviewBudget').textContent = money(cap);
  $('overviewSpent').textContent = money(spent);
  $('overviewRemaining').textContent = state.remaining >= 0 ? `${money(state.remaining)} remains` : 'Above the updated cap · no booking auto-cancelled';
  $('overviewRemaining').classList.toggle('over', state.remaining < 0);
  $('budgetMeterFill').style.width = `${Math.max(0, Math.min(100, spent / cap * 100))}%`;
  $('budgetMeter').setAttribute('aria-valuemax', String(cap));
  $('budgetMeter').setAttribute('aria-valuenow', String(Math.max(0, Math.min(cap, spent))));
  $('budgetMeter').setAttribute('aria-valuetext', `${money(spent)} used in the simulation out of ${money(cap)} maximum extra cash`);
}
function renderDetails() {
  const profile = state.sample_profile;
  $('profileMount').innerHTML = profile ? `<strong>✳ ${escapeHTML(profile.traveller)} · details ready</strong><small>${escapeHTML(profile.vault_note)}</small>` : '';
  if (document.activeElement !== $('budgetInput')) $('budgetInput').value = state.preferences.max_extra;
  $('budgetValue').textContent = money(state.preferences.max_extra);
  $('roadToggle').checked = state.preferences.avoid_overnight_road;
  $('accessToggle').checked = state.preferences.step_free_only;
  const conflicts = state.active_conflicts || [];
  const warning = $('conflictNote');
  warning.hidden = !conflicts.length && state.remaining >= 0;
  warning.textContent = [...conflicts, ...(state.remaining < 0 ? ['Existing simulated spend exceeds the new limit.'] : [])].join(' ') + ' No confirmed booking was auto-cancelled.';
  $('journeyMount').innerHTML = state.journey.map((leg) => `<div class="journey-line"><span class="journey-symbol ${escapeHTML(leg.tone)}" aria-hidden="true">${leg.icon === 'plane' ? '✈' : leg.icon === 'train' ? '▤' : leg.icon === 'car' ? '↗' : '⌂'}</span><div><strong>${escapeHTML(leg.title)}</strong><p>${escapeHTML(leg.detail)}</p></div><span>${escapeHTML(leg.status)}</span></div>`).join('');
  $('rejectedMount').innerHTML = state.rejected.length ? state.rejected.map((item) => `<div class="reason-line"><div><strong>${escapeHTML(item.title)}</strong><p>${escapeHTML(item.reason)}</p></div></div>`).join('') : '<p class="empty-detail">No alternatives have been rejected yet.</p>';
  const labels = {verified:'Confirmed in demo', attention:'Attention', pending:'To do', superseded:'History'};
  const symbols = {verified:'✓', attention:'!', pending:'·', superseded:'↺'};
  $('ledgerMount').innerHTML = state.actions.length ? state.actions.map((item) => `<div class="ledger-line"><span class="ledger-symbol ${escapeHTML(item.state)}" aria-hidden="true">${symbols[item.state] || '·'}</span><div><strong>${escapeHTML(item.title)}</strong><p>${escapeHTML(item.detail)}</p></div><span>${labels[item.state] || 'History'}</span></div>`).join('') : '<p class="empty-detail">No recovery action has been taken. Suggestions are not bookings.</p>';
  $('downloadButton').disabled = state.phase !== 'complete';
}
function render() {
  if (!state) return;
  document.querySelector('.assistant').classList.toggle('has-options', ['flight_alert', 'hotel_alert'].includes(state.phase));
  renderStatus();
  renderWelcome();
  renderOptions();
  renderPending();
  renderSuggestions();
  renderOverview();
  renderDetails();
}

function downloadItinerary() {
  if (state?.phase !== 'complete') return toast('Finish the demo recovery first.');
  const rows = [
    'TRIP RESCUE — ILLUSTRATIVE ITINERARY',
    'SIMULATION ONLY · NOT A TICKET OR HOTEL RESERVATION',
    'Traveller: Ananya (fictional)',
    `Goal: ${state.arrival_goal}`,
    `Extra cash after confirmed demo reversals: ${money(state.gross_extra)}`,
    '', 'CURRENT JOURNEY',
    ...state.journey.map((leg) => `${leg.title} · ${leg.time} · ${leg.status}`),
    '', 'ACTION RECORD',
    ...state.actions.map((a) => `[${a.state.toUpperCase()}] ${a.title}: ${a.detail}`),
    '', 'No real booking, payment, cancellation or refund took place.',
  ];
  const url = URL.createObjectURL(new Blob([rows.join('\n')], {type:'text/plain;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'trip-rescue-demo-itinerary.txt';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function applyResponse(data, {spokenTranscript = false} = {}) {
  if (data.restarted) { log.replaceChildren(); bookingIntent = null; sessionStorage.removeItem(bookingKey); }
  else if (spokenTranscript && data.transcript) addMessage('user', data.transcript);
  if (data.state) state = data.state;
  const context = data.conversation || data;
  pending = context.pending ?? null;
  suggestions = context.suggestions || [];
  render();
  renderBooking(data.booking);
  addMessage('assistant', data.reply || data.error || 'I have checked the sample trip.');
  if (data.restarted) requestAnimationFrame(() => window.scrollTo({top:0, behavior:'smooth'}));
  else if (pending && innerWidth <= 650) requestAnimationFrame(() => $('confirmationMount').scrollIntoView({block:'nearest', behavior:'smooth'}));
  if (data.download) downloadItinerary();
  if (data.notice) toast(data.notice);
  busy = false;
  if (suppressNextSpeech) {
    suppressNextSpeech = false;
    activeConversation = false;
    setMicState('idle');
  } else speak(data.reply || 'I have checked the sample trip.');
}
async function sendText(text) {
  const phrase = String(text || '').trim().slice(0, 500);
  if (!phrase || busy || !state) return;
  if (micState === 'listening') stopMic(true);
  clearTimeout(rearmTimer);
  cancelSpeech();
  suppressNextSpeech = false;
  busy = true;
  setMicState('thinking');
  addMessage('user', phrase);
  const placeholder = thinking();
  try {
    const response = await fetch('/api/conversation', {method:'POST', headers:{'Content-Type':'application/json','X-Trip-Session':session}, body:JSON.stringify({text:phrase})});
    const data = await response.json();
    placeholder.remove();
    if (!response.ok) throw new Error(data.error || 'The demo could not understand that request.');
    applyResponse(data);
  } catch (error) {
    placeholder.remove();
    busy = false;
    activeConversation = false;
    setMicState('idle');
    addMessage('assistant', 'I lost the connection. Refresh to check the current trip status before retrying an approval.');
    toast(error.message || 'Connection lost.');
  }
}
async function bookPlan(plan) {
  if (busy || !state || !['flight_alert','hotel_alert'].includes(state.phase)) return;
  endConversation();
  suppressNextSpeech = false;
  busy = true;
  setMicState('thinking');
  const consent = `Yes, book ${plan.title} for ${money(plan.price)} in this demo`;
  const sameIntent = bookingIntent && bookingIntent.plan_id === plan.id && bookingIntent.revision === state.revision && bookingIntent.price === plan.price;
  if (!sameIntent) {
    bookingIntent = {plan_id: plan.id, revision: state.revision, price: plan.price, consent,
      request_id: (globalThis.crypto?.randomUUID?.() || `request-${Date.now()}-${Math.floor(Math.random() * 100000)}`).replace(/[^a-zA-Z0-9_-]/g, '')};
    sessionStorage.setItem(bookingKey, JSON.stringify(bookingIntent));
  }
  addMessage('user', `Approve ${plan.title} · ${money(plan.price)} extra · virtual booking`);
  const placeholder = thinking();
  try {
    const response = await fetch('/api/book', {method:'POST', headers:{'Content-Type':'application/json','X-Trip-Session':session}, body:JSON.stringify(bookingIntent)});
    const data = await response.json();
    placeholder.remove();
    bookingIntent = null; // A server response, including rejection, is a definitive outcome.
    sessionStorage.removeItem(bookingKey);
    applyResponse(data);
  } catch (error) {
    placeholder.remove();
    busy = false;
    setMicState('idle');
    addMessage('assistant', 'The connection dropped, so I cannot tell whether that demo request was recorded. I will not retry automatically. Refresh to check the action record before choosing again.');
    toast(error.message || 'Connection lost; check the trip before retrying.');
  }
}
async function sendAudio(blob, mime) {
  if (busy) return;
  suppressNextSpeech = false;
  busy = true;
  setMicState('thinking');
  const placeholder = thinking();
  try {
    const response = await fetch('/api/voice', {method:'POST',headers:{'Content-Type':mime,'X-Trip-Session':session},body:blob});
    const data = await response.json();
    placeholder.remove();
    if (!response.ok) throw new Error(data.error || 'Voice service unavailable.');
    applyResponse(data, {spokenTranscript:true});
  } catch (error) {
    placeholder.remove();
    busy = false;
    activeConversation = false;
    $('autoListen').checked = false;
    setMicState('idle');
    addMessage('assistant', 'I could not hear that clearly. Please type the request or try again. No new action was taken by this failed transcription.');
    toast(error.message || 'Voice unavailable.');
  }
}

function cleanupRecording(rec) {
  if (rec.raf) cancelAnimationFrame(rec.raf);
  rec.stream?.getTracks().forEach((track) => track.stop());
  if (rec.context) void rec.context.close().catch(() => {});
}
function stopMic(discard = false, manualFinish = false) {
  if (listening) {
    const current = listening;
    current.discard = discard;
    try { discard ? current.recognizer.abort() : current.recognizer.stop(); } catch { /* Already stopped. */ }
    if (discard) { listening = null; setMicState('idle'); }
    return;
  }
  if (recording) {
    recording.discard = discard;
    recording.manualFinish = manualFinish;
    if (recording.recorder.state !== 'inactive') recording.recorder.stop();
    return;
  }
}
async function startCloudMic() {
  micStarting = true;
  setMicState('starting');
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true, noiseSuppression:true, autoGainControl:true}});
    if (!activeConversation) { stream.getTracks().forEach((t) => t.stop()); micStarting = false; setMicState('idle'); return; }
    const recorder = new MediaRecorder(stream, {mimeType:audioMime, audioBitsPerSecond:64000});
    const rec = {recorder, stream, chunks:[], context:null, raf:null, discard:false, manualFinish:false, heard:false, lastVoice:0, began:performance.now()};
    recording = rec;
    recorder.ondataavailable = (event) => { if (event.data?.size) rec.chunks.push(event.data); };
    recorder.onerror = () => {
      rec.discard = true;
      activeConversation = false;
      $('autoListen').checked = false;
      toast('Microphone recording failed. You can type instead.');
      try { if (recorder.state !== 'inactive') recorder.stop(); } catch { cleanupRecording(rec); recording = null; setMicState('idle'); }
    };
    recorder.onstop = () => {
      cleanupRecording(rec);
      if (recording === rec) recording = null;
      if (rec.discard) { setMicState('idle'); return; }
      const blob = new Blob(rec.chunks, {type:recorder.mimeType || audioMime});
      if ((!rec.heard && !rec.manualFinish) || blob.size < 100) {
        activeConversation = false;
        $('autoListen').checked = false;
        setMicState('idle');
        toast('I did not hear a request. Tap to try again.');
        return;
      }
      void sendAudio(blob, (recorder.mimeType || audioMime).split(';')[0]);
    };
    recorder.start();
    micStarting = false;
    setMicState('listening');
    const AudioContextType = window.AudioContext || window.webkitAudioContext;
    let autoPauseReady = false;
    if (AudioContextType) {
      try {
        const context = new AudioContextType();
        rec.context = context;
        if (context.state === 'suspended') void context.resume().catch(() => {});
        const source = context.createMediaStreamSource(stream);
        const analyser = context.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        const bytes = new Uint8Array(analyser.fftSize);
        const tick = () => {
          if (recording !== rec || rec.recorder.state !== 'recording') return;
          analyser.getByteTimeDomainData(bytes);
          let total = 0;
          for (const value of bytes) total += ((value - 128) / 128) ** 2;
          const energy = Math.sqrt(total / bytes.length);
          const now = performance.now();
          if (energy > 0.018) { rec.heard = true; rec.lastVoice = now; }
          if (rec.heard && now - rec.lastVoice > 1050 && now - rec.began > 1250) { stopMic(); return; }
          if ((!rec.heard && now - rec.began > 6500) || now - rec.began > 13000) { stopMic(); return; }
          rec.raf = requestAnimationFrame(tick);
        };
        rec.raf = requestAnimationFrame(tick);
        autoPauseReady = true;
      } catch {
        if (rec.context) void rec.context.close().catch(() => {});
        rec.context = null;
      }
    }
    if (!autoPauseReady) {
      // Some browsers allow recording but not Web Audio analysis: tap to send.
      rec.heard = true;
      $('micHint').textContent = 'Tap again to send. Automatic pause is unavailable here.';
      setTimeout(() => { if (recording === rec) stopMic(); }, 12000);
    }
  } catch (error) {
    if (recording?.stream === stream) {
      recording.discard = true;
      try { if (recording.recorder.state !== 'inactive') recording.recorder.stop(); } catch { /* Start may have failed. */ }
      recording = null;
    }
    stream?.getTracks().forEach((track) => track.stop());
    micStarting = false;
    activeConversation = false;
    $('autoListen').checked = false;
    setMicState('idle');
    toast(error?.name === 'NotAllowedError' ? 'Microphone permission was denied. You can type instead.' : 'Microphone could not start here. Try typing your request.');
  }
}
function startBrowserMic() {
  if (!Recognition) { toast('Speech recognition is not available here. Type your request instead.'); activeConversation = false; setMicState('idle'); return; }
  const recognizer = new Recognition();
  recognizer.lang = navigator.language?.startsWith('en') ? navigator.language : 'en-IN';
  recognizer.interimResults = true;
  recognizer.continuous = false;
  recognizer.maxAlternatives = 1;
  const current = {recognizer, final:'', interim:'', error:'', discard:false};
  listening = current;
  recognizer.onstart = () => { if (listening === current) setMicState('listening'); };
  recognizer.onresult = (event) => {
    let final = '', interim = '';
    for (const result of event.results) {
      if (result.isFinal) final += result[0]?.transcript || '';
      else interim += result[0]?.transcript || '';
    }
    current.final = final.trim();
    current.interim = interim.trim();
    if (listening === current) $('micHint').textContent = current.final || current.interim || 'Listening…';
  };
  recognizer.onerror = (event) => { current.error = event.error || 'unknown'; };
  recognizer.onend = () => {
    if (listening !== current) return;
    listening = null;
    setMicState('idle');
    if (current.discard || !activeConversation) return;
    const phrase = current.final || current.interim;
    if (phrase) void sendText(phrase);
    else {
      activeConversation = false;
      $('autoListen').checked = false;
      setMicState('idle');
      toast(current.error === 'not-allowed' ? 'Microphone permission was denied. You can type instead.' : 'I did not hear a request. Tap to try again.');
    }
  };
  try { recognizer.start(); }
  catch { listening = null; activeConversation = false; setMicState('idle'); toast('Browser speech could not start. You can type instead.'); }
}
async function startMic() {
  if (micStarting || busy || micState === 'listening' || !state) return;
  clearTimeout(rearmTimer);
  cancelSpeech();
  suppressNextSpeech = false;
  activeConversation = true;
  $('endConversation').hidden = false;
  if (capabilities.ai_enabled && canRecord) await startCloudMic();
  else startBrowserMic();
}
function endConversation() {
  activeConversation = false;
  suppressNextSpeech = true;
  $('autoListen').checked = false;
  clearTimeout(rearmTimer);
  stopMic(true);
  cancelSpeech();
  if (!busy) setMicState('idle');
  $('endConversation').hidden = true;
}

$('micButton').addEventListener('click', () => {
  if (micState === 'listening') stopMic(false, true);
  else if (micState === 'speaking') { cancelSpeech(); void startMic(); }
  else if (micState === 'idle') void startMic();
});
$('endConversation').addEventListener('click', endConversation);
$('soundButton').addEventListener('click', () => {
  soundOn = !soundOn;
  $('soundButton').setAttribute('aria-pressed', String(soundOn));
  $('soundButton').textContent = soundOn ? '◖))' : '◖×';
  $('soundButton').setAttribute('aria-label', soundOn ? 'Turn spoken replies off' : 'Turn spoken replies on');
  if (!soundOn) cancelSpeech();
});
$('autoListen').addEventListener('change', () => {
  if (!$('autoListen').checked && micState === 'idle') activeConversation = false;
  if ($('autoListen').checked && micState === 'idle') toast('After your next spoken request, I’ll listen again until you tap End.');
  $('endConversation').hidden = !activeConversation;
});
$('messageForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const text = $('messageInput').value;
  $('messageInput').value = '';
  void sendText(text);
});
function openTripDetails() {
  const details = $('tripDetails');
  details.open = true;
  $('overviewDetailsButton').setAttribute('aria-expanded', 'true');
  details.scrollIntoView({block:'start', behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
  details.querySelector('summary').focus({preventScroll:true});
}
$('overviewDetailsButton').addEventListener('click', openTripDetails);
$('tripDetails').addEventListener('toggle', () => $('overviewDetailsButton').setAttribute('aria-expanded', String($('tripDetails').open)));
$('optionMount').addEventListener('click', (event) => {
  if (event.target.closest('[data-open-limits]')) { openTripDetails(); return; }
  const review = event.target.closest('[data-plan-review]');
  const book = event.target.closest('[data-plan-book]');
  const plan = state?.plans.find((p) => p.id === (review?.dataset.planReview || book?.dataset.planBook));
  if (!plan) return;
  if (review) void sendText(`Tell me about ${plan.title}`);
  else void bookPlan(plan);
});
$('confirmationMount').addEventListener('click', (event) => {
  const choice = event.target.closest('[data-confirm]')?.dataset.confirm;
  if (!choice) return;
  if (choice === 'cancel') void sendText('No, not now');
  else if (choice === 'reset') void sendText('Yes, restart the demo');
  else if (choice === 'plan' && pending) void sendText(`Yes, confirm ${pending.title} for ${money(pending.price)} in this demo`);
});
$('resetButton').addEventListener('click', () => void sendText('Please restart the demo'));
$('budgetSave').addEventListener('click', () => {
  const amount = Number($('budgetInput').value);
  if (!Number.isInteger(amount) || amount < 500 || amount > 8000) { toast('Choose a limit between ₹500 and ₹8,000.'); return; }
  void sendText(`Please set my extra-cash limit to ${amount} rupees`);
});
$('roadToggle').addEventListener('change', (event) => void sendText(event.target.checked ? 'I do not want overnight road travel' : 'Road is fine again'));
$('accessToggle').addEventListener('change', (event) => void sendText(event.target.checked ? 'I need verified step-free access' : 'I do not need step-free access now'));
$('downloadButton').addEventListener('click', () => void sendText('Download my demo itinerary'));
document.addEventListener('visibilitychange', () => { if (document.hidden) endConversation(); });

async function initialize() {
  try {
    const [tripResponse, modeResponse] = await Promise.all([
      fetch('/api/state', {headers:{'X-Trip-Session':session}}),
      fetch('/api/capabilities'),
    ]);
    if (!tripResponse.ok || !modeResponse.ok) throw new Error('Demo server unavailable.');
    const trip = await tripResponse.json();
    capabilities = await modeResponse.json();
    state = trip.state;
    if (!['flight_alert','hotel_alert'].includes(state.phase)) {
      bookingIntent = null;
      sessionStorage.removeItem(bookingKey);
    }
    pending = trip.conversation?.pending || null;
    suggestions = trip.conversation?.suggestions || [];
    updateMode();
    render();
    const greeting = pending?.kind === 'plan'
      ? `Welcome back. We were reviewing ${pending.title} for ${money(pending.price)}. Would you like to confirm it in this demo or look at something else?`
      : state.phase === 'ready'
        ? "Hi, I'm here with Ananya's sample journey. Tell me what's going on, in your own words."
        : "I'm here. Tell me what you'd like to know about the current trip.";
    addMessage('assistant', greeting);
  } catch {
    $('statusMount').textContent = 'Could not load the demo. Refresh the page to try again.';
    $('micButton').disabled = true;
    $('messageInput').disabled = true;
    toast('Demo server unavailable.');
  }
}
void initialize();
