# Trip Rescue

**Get there for what matters.** A voice-first, fictional travel-recovery prototype. Ananya wants to reach Mysuru for her mother’s 60th-birthday breakfast. A late flight threatens her train and hotel; after she chooses a replacement, the room can fail too. Trip Rescue holds the *whole connected journey* in view without pretending a search result is a booking.

> **What runs today:** a responsive web app, an in-memory simulator, an accessible guided conversation, optional server-side speech transcription + language-model interpretation, browser speech fallback, and a **virtual booking-app gateway**. Once the available choices and prices are shown, one clear voice/typed instruction *or* one plan-card click triggers a final recheck and automatically handles every required **simulated** ticket, cab or room step. It reuses a fictional prefilled traveller profile, shows separate demo receipts, and never silently cancels an original booking. **No real inbox, Aadhaar/PAN vault, live supplier, payment, ticket, cab or room is connected.**

## Start in under a minute

Python 3.10+; no `pip install`, npm build, account or key is required for the guided demo.

```bash
cd trip-rescue
python server.py --port 8000
```

Open **http://localhost:8000**. The server binds to `0.0.0.0` for hosted previews. It serves only the app’s static assets and `/api/*` routes, not its Python source. Each browser tab has an isolated, in-memory sample trip; refresh retains that trip while the server runs, and **Restart** asks for a second confirmation. Restarting the server clears sessions.

### Optional AI voice mode

To enable the cloud path, set **one server-side environment variable** before starting the server:

```bash
export TRIP_RESCUE_AI_API_KEY='your_key_here'  # or OPENAI_API_KEY
python server.py --port 8000
```

Optional configuration: `TRIP_RESCUE_AI_BASE_URL` (default `https://api.openai.com/v1`), `TRIP_RESCUE_STT_MODEL` (default `gpt-transcribe`) and `TRIP_RESCUE_CHAT_MODEL` (default `gpt-5.4-mini`). A custom base must expose compatible `/audio/transcriptions` and `/chat/completions` endpoints; compatibility with third-party services has **not** been tested. The key never goes to the browser. On an actual phone, microphone capture needs user permission and a secure HTTPS origin (localhost is treated specially). [1](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)

**Without a key**, the badge reads **GUIDED DEMO**: if the browser implements `SpeechRecognition`, spoken words become text for the *local guided interpreter*. This browser service may itself process speech remotely; it is not offline/private by default. If speech recognition is unavailable or blocked by an embedded preview, the mic is labelled unavailable and the same conversation works through text or suggestion buttons. With a key and supported `MediaRecorder`, the badge reads **AI VOICE READY** and tapped recordings are sent to the server for transcription and AI interpretation. If recording is unsupported but browser recognition exists, the badge reads **AI TEXT READY** and browser-transcribed text can still use the configured model. Browser API support varies. [2](https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition/SpeechRecognition)

## A judge-ready conversation (about two minutes)

Use the mic if available, or type **the same natural sentences**. You need not memorize commands. The exact spelling of a sentence is not a magic trigger in AI mode; the unconfigured guided fallback understands common patterns but is intentionally more limited.

| Moment | What to say or do | What the judge sees |
|---|---|---|
| 0. Start with the person | “My flight’s running late. Can I still make it to my mother’s breakfast?” | Ananya’s entire Delhi → Bengaluru → Mysuru trip is checked, not just her flight. The sample arrival moves **18:10 → 19:35**. |
| 1. Challenge the conclusion | “Could a metro connection or a faster road transfer still get me to my original train?” | The fixture compares an *optimistic* direct road transfer (**ready to board 21:10**) and a *hypothetical* metro-linked path (**21:35**) against the **20:35** train, including bags and boarding. Both fail *in this synthetic scenario*. Neither path is a verified current service or live traffic check. |
| 2. State a limit only when it matters | “I don’t want overnight road travel.” | The coach disappears from feasible options; the later train and a 24-hour stay remain. The ₹2,500 extra-cash limit and 08:00 goal are enforced by the server. |
| 3. Approve once | “Yes, book the later train for ₹2,140” **or** tap **Approve & book · ₹2,140** on that card. | One specific approval runs the final quote/limit check, then the **Virtual Rail App** handles a ₹690 demo ticket and the **Virtual Stay App** handles a ₹1,450 demo room. Separate `DEMO-` references appear under **NO REAL PURCHASE**. The original train refund and original hotel cancellation are still *pending*, not silently executed. A bare “yes” is refused because two priced options are on screen. |
| 4. Show the cascade | “My hotel just cancelled. What now?” | The previously confirmed *demo* train remains intact; only the stay is re-evaluated. The simulator records a **confirmed ₹1,450 reversal** of the now-cancelled sample room, rather than assuming a pending refund. |
| 5. Finish honestly | “Yes, book Royal Fern House for ₹1,090” or tap its one-click card. | Only the new room goes through **Virtual Stay App**; the train is marked *preserved*. Final simulated net extra cash is **₹1,780**: ₹690 train + ₹1,450 earlier room + ₹1,090 new room − ₹1,450 confirmed reversal. Download the itinerary labelled **not a ticket or hotel reservation**. |

**Alternate branches:** “It’s not worth spending more; I’ll stay in Bengaluru” produces a no-purchase suggestion (slower travel, safe local stay, possible next-day Cubbon Park/Lalbagh *if open*) rather than inventing live attractions. To see a cab option, raise the extra-cash limit to ₹4,000 and explicitly choose **Private car · direct to hotel**; its virtual cab receipt shows a `DEMO-CAB-` reference and keeps the original room. To demonstrate a safe failure, restart; say “I’d like the coach” (a softer phrase that stages a review); say “test sold out”; then “Yes, confirm the coach.” The final check stops with **no new booking, payment, or original-ticket cancellation**, and a different feasible option can be reviewed. “Tell me more,” followed by “I want that one,” stages a review rather than purchasing immediately.

## Why the interface is deliberately quiet

One screen has one primary task: **talk to the copilot**. The emotional opening makes the deadline human; the mic and text composer come first on a phone, before the conversation grows. Comparable priced plan cards ask which option to book. A clear “Book the later train for ₹2,140” by voice or type is **one approval**, not two confirmation rounds; a single **Approve & book** click is the equivalent button path. Softer wording (“I’d like that one”) stages a review, and an unqualified “yes” never selects among multiple offers. The receipt lists each virtual booking-app step. Beneath the copilot, a **connected-trip overview** shows the three current legs and remaining cash, while a short **How it works** section explains the recovery path. The compact **See the whole trip** disclosure holds the detailed itinerary, prefilled *sample* traveller-details status, limits, rejected alternatives and action ledger. There is no up-front booking-upload wizard or long emergency questionnaire. At 320 × 568 px the mic remains in the opening viewport; the page scrolls naturally instead of trapping options in a tiny nested pane. Text and buttons remain accessible in noisy places or unsupported browsers. The local hero illustration is a ~139 KB WebP, not a remote asset.

**Voice interaction:** tap the mic, talk normally, pause for approximately a second after speech (when browser audio analysis works), or tap again to send. A quiet voice can use the manual tap instead of being rejected by the silence detector. Optional **Keep listening after replies** reopens the mic *only after the traveller opts in*; **End** stops it and discards a pending recording. A new mic tap can interrupt browser-spoken output. Spoken replies use the browser’s `speechSynthesis` when available and can be switched off; all answers remain visible as text. This is **turn-based** speech-to-text → decision → browser TTS, not full-duplex streaming or a guarantee of seamless barge-in. [3](https://developers.openai.com/api/docs/guides/voice-agents)

### The trust boundary behind a natural conversation

```text
Tap + permission → short recording → optional server-side STT → redacted transcript
                                                     ↓
Browser recognition/text ───────────────→ model interpreter (optional) / guided fallback
                                                     ↓
                                allowlisted, text-grounded actions + conversation memory
                                                     ↓
                              deterministic TripEngine checks current version + constraints
                                                     ↓
                         priced options shown → one named voice/type approval OR one click
                                                     ↓
                   server checks exact revision + price + consent → final feasibility recheck
                                                     ↓
                  VirtualBookingGateway → demo ticket / cab / room steps → labelled receipts
                                                     ↓
                         truthful reply + action ledger; old booking never auto-cancelled
```

- `conversation.py` retains short context (“that one,” previous answer, pending review) and the exact **prices/revision already shown**. An explicit “Book [named plan]” or its unique price after those options is one approval turn. Softer choices stage a review; ambiguous “yes,” changed conditions, competing plans, hypotheticals and stale quotes do not book. The optional model **interprets words; it does not set prices, declare feasibility or authorise a booking**; a local consent gate checks the traveller’s actual text/transcript.
- `engine.py` is the authority for connected flight/transfer/rail/stay timing, verified-in-fixture access rules, capacity, extra cash, preservation, quote revision and simulated confirmations. Every action rechecks all hard constraints. A real supplier would need a fresh offer, explicit traveller consent and a verified provider confirmation; this demo substitutes deterministic fixtures.
- `booking_apps.py` is the **virtual adapter boundary**. It decomposes a complete plan into priced demo-app steps: ticket + room, cab + preserved room, coach + preserved room, or room + preserved travel. The component sum must equal the approved extra price. Its `DEMO-TR-`, `DEMO-CAB-` and `DEMO-HT-` references are not real tickets or ride assignments. No ID numbers are stored or transmitted; the fictional profile is prefilled only in the story.
- `server.py` keeps the optional AI key server-side, bounds requests, isolates in-memory demo sessions and does not log audio/transcripts. `POST /api/book` verifies a displayed plan, exact price and revision, explicit plan-specific consent, then asks the engine for a final recheck under a lock. A bounded **request ID** makes repeat submissions idempotent within that running server; it does not provide cross-restart or real-provider transaction guarantees. `ai_bridge.py` provides the optional bounded cloud calls and a labelled guided fallback.
- The browser shows the recognised transcript so the traveller can catch mistakes. An explicit, plan-specific approval is required before **any simulated confirmation**; no generic “yes,” question or “confirm X instead of Y” can silently approve another plan. On one-click network uncertainty, the browser does **not** automatically retry; it asks the traveller to check the ledger. A confirmed simulated reversal can reduce net spend; a merely requested refund cannot.

### The one-tap virtual booking contract

After `GET /api/state` has displayed the plans to the traveller, the button sends one bounded request to `POST /api/book` with the session header. Example for the fictional later-train plan (use the **current** state revision and price, not these example numbers blindly):

```http
POST /api/book
X-Trip-Session: <opaque browser-session token>
Content-Type: application/json

{"plan_id":"rail","revision":1,"price":2140,
 "consent":"Yes, book the later train for ₹2,140 in this demo",
 "request_id":"a-unique-random-id-per-intended-action"}
```

The response contains `state`, a short `reply`, and a `booking` object with `simulation:true`, `live_booking:false`, the exact total and each **virtual** app step (`kind`, `app`, `item`, `price`, `status`, `reference`, `real_booking:false`). On stale revision, wrong fare, changed limits or sold-out inventory it returns **409** with refreshed state and *no receipt*. The same request ID with the same fields returns a replay indicator and does not create a second simulated booking; reusing it for different fields is rejected. A typed/spoken approval reaches the same virtual gateway through `/api/conversation` or `/api/voice`, with its offer and specific-consent gate enforced server-side. `POST /api/approve` remains a reviewed-quote compatibility route.

This is **not an app-deep-link purchase or production reservation**. A live adapter needs provider-approved API credentials for each mode, traveller authentication and scoped permission, a usable payment method, current offer/hold terms, verified booking/issuance or ride assignment, durable per-provider idempotency, and an outbox/saga for partial failures. Never map a “hold,” redirect, payment attempt or submitted booking request to “ticket issued.” A provider lacking a permitted transactional API must fall back to an honest handoff or human help, not a fabricated receipt. No such credentials or payment authority were supplied for this prototype.

### Why accent support is an evaluation problem, not a badge

The optional cloud speech adapter can exploit a modern recogniser and a short vocabulary hint for **Bengaluru, Mysuru, hotel names and rupee amounts**; browser capture requests echo/noise suppression, and manual tap avoids cutting off quiet speakers. That is a sensible starting point, **not evidence that different accents are now reliably recognised**. Svarah, an Indian-accented English benchmark with **117 speakers across 65 geographic locations**, shows why clean US-English speech scores do not establish Indian-accent performance. [4](https://arxiv.org/html/2305.15760v1) Whisper’s large-scale weakly supervised approach improved broad transfer, but its results do not validate this prototype’s chosen transcription endpoint or every accent. [5](https://proceedings.mlr.press/v202/radford23a/radford23a.pdf)

Before claiming accuracy, collect **consented, diverse, real-device** utterances in traffic/noise, including Indian regional accents, code-switching, alternative place names, spoken prices, negation and consent. Measure word error rate **and critical-slot error** (destination, time, rupees, “no,” plan identity), per-speaker subgroup, correction rate, false confirmation rate and median/p95 end-to-end latency. Compare browser recognition and the configured service on the *same* samples. The Svarah data can be an additional benchmark subject to its licence; travel-domain consent phrases need separate collection. No such live-device study or cloud-key test has been performed here.

## What is synthetic, and what a real product would need

- **Discovery:** the prototype starts with a seeded itinerary. A real traveller would separately **authorise email access** to extract flight/rail tickets, hotel confirmations and references; booking-upload forms are not the primary itinerary source. The previously populated passenger/document vault would be reused *only* when an authorised booking provider requires the data or a document. This prototype has **no email OAuth, extraction pipeline, document store or Aadhaar/PAN handling**; do not enter ID numbers.
- **Earlier signals:** a real system could combine airline/rail status, station/baggage and provider changes with probabilistic indications such as satellite-received ADS-B aircraft positions. ADS-B can suggest connection risk before an agent messages the traveller; it is **not** the airline’s authoritative cancellation or a verified arrival prediction. [6](https://aireon.com/its-just-ads-b/)
- **Transfers:** the sample compares *assumed* metro-linked and road timing before rejecting the original train. Production must verify whether the relevant metro service actually exists, its timetable, road traffic, transfers, bags, boarding cutoff and accessible route in real time. The sample is **not** a live Bengaluru transit planner.
- **Transactions:** supplier offers can expire. Search, reservation, ticket issuance and confirmation are different states. [7](https://support.travelport.com/webhelp/JSONAPIs/Airv11/Content/Air11/Book/BookingGuide.htm) Real rail e-ticketing would need an appropriately authorised integration; informational IRCTC access does not itself permit booking. [8](https://contents.irctc.co.in/en/TIES_Policy.pdf) The demo’s instant multi-app action is **atomic only because it is a local simulation**. A real train-plus-room workflow can partly succeed and needs verified receipts, reconciliation and human recovery. No supplier side effect is implemented here.
- **Privacy/operations:** a production version would need account authentication, scoped consent, encryption, retention/deletion controls, supplier contracts, rate limits, observability without sensitive transcripts, incident support and a human handoff. The current server is a single-process hackathon demo, **not** a secure personal-data backend.

## Verify it yourself

```bash
python -m unittest -q test_engine.py test_conversation.py test_server.py test_ai_bridge.py
node --check app.js
```

At the time of this README update, **59 Python tests pass**: transfer comparison, hard constraints, sequential hotel repair, simulated refund accounting, stale/sold-out stops, voice/typed plan-specific approvals, ticket+room and cab receipts, one-tap price/revision/consent checks, idempotent retries, HTTP endpoints and stubbed AI calls. The **browser speech, one-tap, narrow-mobile and cloud UI paths are tested with mocks**, not real microphones, provider credentials or a paid model:

```bash
playwright-cli -s=arena open http://127.0.0.1:8000 --browser=chromium
playwright-cli -s=arena run-code --filename=test_voice_browser.js
playwright-cli -s=arena close
```

Files: `index.html` + `styles.css` + `app.js` are the simple web client; `engine.py` handles recovery; `conversation.py` handles bounded dialogue; `booking_apps.py` implements the **virtual** booking-app gateway; `ai_bridge.py` is the optional server-only speech/language adapter; `server.py` exposes `GET /api/capabilities`, `GET /api/state`, `POST /api/conversation`, `POST /api/voice`, `POST /api/book`, and deterministic demo/reset/preference/approval endpoints. `public/journey-hero.webp` is a local illustration. `test_*.py` and `test_voice_browser.js` exercise safety and flows. The companion product/prior-work write-up is [`../docs/proposal.md`](../docs/proposal.md).

**The differentiator is not “AI plus maps.”** Multimodal recovery, preemptive rerouting and LLM+constraint-solving have prior art. This entry combines a fast human-scale conversation with **rolling, connected cross-provider repair, traveller-owned limits and honest commitment states**. Its best demo moment is when a quote vanishes and Trip Rescue says *nothing was bought or cancelled*—then still finds the next safe move.
