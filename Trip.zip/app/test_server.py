"""HTTP integration checks for the demo; cloud calls are stubbed, not real."""
import json
import os
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from uuid import uuid4

import ai_bridge
import server


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)
        with server.LOCK:
            server.SESSIONS.clear()
            server.MEMORIES.clear()

    def setUp(self):
        self.token = uuid4().hex
        self.environment = patch.dict(os.environ, {"TRIP_RESCUE_AI_API_KEY": "", "OPENAI_API_KEY": ""})
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def request(self, method, path, payload=None, content_type="application/json", token=None):
        body = (json.dumps(payload).encode("utf-8") if isinstance(payload, (dict, list)) else payload)
        headers = {"X-Trip-Session": token or self.token}
        if body is not None:
            headers["Content-Type"] = content_type
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=body, headers=headers, method=method
        )
        try:
            response = urllib.request.urlopen(request, timeout=4)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            content = response.read()
            try:
                data = json.loads(content)
            except (ValueError, UnicodeDecodeError):
                data = content.decode("utf-8", errors="replace")
            return response.status, data

    def test_guided_endpoint_and_session_isolation(self):
        status, caps = self.request("GET", "/api/capabilities")
        self.assertEqual(status, 200)
        self.assertFalse(caps["ai_enabled"])
        status, answer = self.request("POST", "/api/conversation", {"text": "My flight's running late. I can spend at most ₹1,500."})
        self.assertEqual(status, 200)
        self.assertEqual(answer["mode"], "guided")
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertEqual(answer["state"]["preferences"]["max_extra"], 1500)
        self.assertEqual([p["id"] for p in answer["state"]["plans"]], ["coach"])
        _, another = self.request("GET", "/api/state", token=uuid4().hex)
        self.assertEqual(another["state"]["phase"], "ready")
        status, voice = self.request("POST", "/api/voice", b"0" * 150, "audio/webm")
        self.assertEqual(status, 503)
        self.assertIn("server-side API key", voice["error"])

    def test_mock_cloud_audio_transcription_and_grounded_interpretation(self):
        spoken = "My flight is delayed; my email is ananya@example.com."
        with patch.object(ai_bridge, "enabled", return_value=True), \
             patch.object(ai_bridge, "transcribe", return_value=spoken) as stt, \
             patch.object(ai_bridge, "interpret", return_value={"actions": [{"type": "flight_delay"}], "focus": "options", "reply": ""}) as model:
            status, answer = self.request("POST", "/api/voice", b"fake-webm-audio" * 20, "audio/webm")
        self.assertEqual(status, 200)
        self.assertEqual(answer["mode"], "ai")
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertNotIn("ananya@example.com", answer["transcript"])
        self.assertNotIn("ananya@example.com", model.call_args.args[0])
        stt.assert_called_once()
        self.assertIn("demo", answer["reply"])

    def test_provider_failure_falls_back_to_guided_turn(self):
        with patch.object(ai_bridge, "enabled", return_value=True), \
             patch.object(ai_bridge, "interpret", side_effect=ai_bridge.AIUnavailable("offline")):
            status, answer = self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        self.assertEqual(status, 200)
        self.assertEqual(answer["mode"], "guided")
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertIn("guided fallback", answer["notice"])

    def test_two_step_approval_and_safe_sold_out_stop_over_http(self):
        self.request("POST", "/api/conversation", {"text": "The flight is delayed"})
        _, staged = self.request("POST", "/api/conversation", {"text": "I'd like the coach"})
        self.assertEqual(staged["pending"]["plan_id"], "coach")
        _, generic = self.request("POST", "/api/conversation", {"text": "Yes"})
        self.assertEqual(generic["state"]["phase"], "flight_alert")
        status, changed = self.request("POST", "/api/offer/sellout", {"plan_id": "coach"})
        self.assertEqual(status, 200)
        self.assertEqual(changed["conversation"]["pending"]["plan_id"], "coach")
        status, failed = self.request("POST", "/api/conversation", {"text": "Yes, confirm the coach"})
        self.assertEqual(status, 200)
        self.assertEqual(failed["state"]["phase"], "flight_alert")
        self.assertEqual(failed["state"]["gross_extra"], 0)
        self.assertIn("sold out", failed["reply"])
        self.assertIsNone(failed["pending"])

    def test_legacy_approval_endpoint_requires_review_and_specific_consent(self):
        _, delayed = self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        quote_revision = delayed["state"]["revision"]
        status, refused = self.request("POST", "/api/approve", {"plan_id": "coach", "revision": quote_revision,
                                                            "consent": "Yes, confirm the coach"})
        self.assertEqual(status, 409)
        self.assertEqual(refused["state"]["gross_extra"], 0)
        _, staged = self.request("POST", "/api/conversation", {"text": "I want the coach"})
        self.assertEqual(staged["pending"]["plan_id"], "coach")
        status, refused = self.request("POST", "/api/approve", {"plan_id": "coach", "revision": quote_revision,
                                                            "consent": "yes"})
        self.assertEqual(status, 409)
        self.assertEqual(refused["state"]["phase"], "flight_alert")
        status, approved = self.request("POST", "/api/approve", {"plan_id": "coach", "revision": quote_revision,
                                                              "consent": "Yes, confirm the coach"})
        self.assertEqual(status, 200)
        self.assertEqual(approved["state"]["phase"], "travel_secured")
        self.assertEqual(approved["state"]["gross_extra"], 1150)

    def book_payload(self, state, plan_id, request_id=None, consent=None):
        plan = next(p for p in state["plans"] if p["id"] == plan_id)
        return {"request_id": request_id or uuid4().hex, "plan_id": plan_id,
                "revision": state["revision"], "price": plan["price"],
                "consent": consent or f"Yes, book {plan['title']} for ₹{plan['price']:,} in this demo"}

    def test_one_tap_virtual_ticket_and_room_with_idempotent_retry(self):
        self.request("POST", "/api/conversation", {"text": "My flight is delayed"})
        _, shown = self.request("GET", "/api/state")
        payload = self.book_payload(shown["state"], "rail")
        status, done = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 200)
        self.assertFalse(done["replayed"])
        self.assertEqual(done["state"]["gross_extra"], 2140)
        self.assertEqual(done["state"]["phase"], "travel_secured")
        receipt = done["booking"]
        self.assertEqual([step["price"] for step in receipt["steps"]], [690, 1450])
        self.assertEqual([step["kind"] for step in receipt["steps"]], ["ticket", "room"])
        self.assertTrue(all(step["reference"].startswith("DEMO-") for step in receipt["steps"]))
        self.assertFalse(any(step["real_booking"] for step in receipt["steps"]))
        self.assertIn("no real identity documents", receipt["profile"])
        count = len(done["state"]["actions"])
        status, replay = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 200)
        self.assertTrue(replay["replayed"])
        self.assertEqual(len(replay["state"]["actions"]), count)
        self.assertEqual(replay["booking"], receipt)
        changed = dict(payload, price=1150)
        status, conflict = self.request("POST", "/api/book", changed)
        self.assertEqual(status, 409)
        self.assertIn("different choice", conflict["error"])

    def test_one_tap_cab_requires_budget_and_stays_virtual(self):
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        _, shown = self.request("GET", "/api/state")
        status, blocked = self.request("POST", "/api/book", {"request_id": uuid4().hex,
            "plan_id": "car", "revision": shown["state"]["revision"], "price": 3900,
            "consent": "Yes, book the cab for 3900"})
        self.assertEqual(status, 409)
        self.assertEqual(blocked["state"]["gross_extra"], 0)
        _, raised = self.request("POST", "/api/conversation", {"text": "Please raise my extra-cash limit to 4000 rupees"})
        self.assertIn("car", [p["id"] for p in raised["state"]["plans"]])
        status, done = self.request("POST", "/api/book", self.book_payload(raised["state"], "car"))
        self.assertEqual(status, 200)
        self.assertEqual(done["state"]["gross_extra"], 3900)
        self.assertEqual(done["booking"]["steps"][0]["app"], "Virtual Cab App")
        self.assertEqual(done["booking"]["steps"][0]["kind"], "cab")
        self.assertTrue(done["booking"]["steps"][0]["reference"].startswith("DEMO-CAB-"))
        self.assertIsNone(done["booking"]["steps"][1]["reference"])
        self.assertIn("No real", done["booking"]["notice"])

    def test_one_tap_rejects_ambiguous_stale_and_sold_out_quotes(self):
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        _, shown = self.request("GET", "/api/state")
        coach = self.book_payload(shown["state"], "coach")
        for change in ({"consent": "yes"}, {"price": 1200}, {"revision": True}):
            status, refusal = self.request("POST", "/api/book", dict(coach, request_id=uuid4().hex, **change))
            self.assertIn(status, (400, 409))
            self.assertEqual(refusal["state"]["gross_extra"], 0)
        self.request("POST", "/api/offer/sellout", {"plan_id": "coach"})
        status, outdated = self.request("POST", "/api/book", dict(coach, request_id=uuid4().hex))
        self.assertEqual(status, 409)
        self.assertEqual(outdated["state"]["gross_extra"], 0)
        _, fresh = self.request("GET", "/api/state")
        payload = self.book_payload(fresh["state"], "coach")
        status, failed = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 409)
        self.assertIn("sold out", failed["error"])
        self.assertEqual(failed["state"]["gross_extra"], 0)
        self.assertEqual([p["id"] for p in failed["state"]["plans"]], ["rail"])
        self.assertIsNone(failed["booking"])
        status, retry = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 409)
        self.assertTrue(retry["replayed"])
        self.assertEqual(retry["state"]["gross_extra"], 0)
        status, backup = self.request("POST", "/api/book", self.book_payload(failed["state"], "rail"))
        self.assertEqual(status, 200)
        self.assertEqual(backup["state"]["phase"], "travel_secured")

    def test_voice_answer_and_typed_hotel_answer_automate_virtual_steps(self):
        self.request("POST", "/api/conversation", {"text": "My flight is delayed"})
        with patch.object(ai_bridge, "enabled", return_value=True), \
             patch.object(ai_bridge, "transcribe", return_value="Yes, book the later train for 2140"), \
             patch.object(ai_bridge, "interpret", return_value={"actions": [{"type": "confirm_plan"}],
                                                             "focus": "answer", "reply": "All paid for."}):
            status, voice = self.request("POST", "/api/voice", b"fake-audio-blob" * 18, "audio/webm")
        self.assertEqual(status, 200)
        self.assertEqual(voice["state"]["phase"], "travel_secured")
        self.assertEqual([s["app"] for s in voice["booking"]["steps"][:2]],
                         ["Virtual Rail App", "Virtual Stay App"])
        self.assertNotIn("paid for", voice["reply"])
        _, alert = self.request("POST", "/api/conversation", {"text": "My hotel has cancelled"})
        self.assertEqual(alert["state"]["phase"], "hotel_alert")
        self.assertEqual(alert["state"]["refund_confirmed"], 1450)
        status, room = self.request("POST", "/api/conversation", {"text": "Yes, book Royal Fern House for 1090"})
        self.assertEqual(status, 200)
        self.assertEqual(room["state"]["phase"], "complete")
        self.assertEqual(room["state"]["gross_extra"], 1780)
        self.assertEqual(room["booking"]["steps"][0]["status"], "preserved in sample itinerary")
        self.assertEqual(room["booking"]["steps"][1]["price"], 1090)
        self.assertFalse(room["booking"]["live_booking"])

    def test_reusing_request_id_after_reset_does_not_rebook(self):
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        _, shown = self.request("GET", "/api/state")
        payload = self.book_payload(shown["state"], "coach")
        self.assertEqual(self.request("POST", "/api/book", payload)[0], 200)
        self.request("POST", "/api/reset", {})
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        status, replay = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 200)
        self.assertTrue(replay["replayed"])
        self.assertIsNone(replay["booking"])
        self.assertEqual(replay["state"]["gross_extra"], 0)
        self.assertEqual(replay["state"]["phase"], "flight_alert")
        _, current = self.request("GET", "/api/state")
        self.assertEqual(self.request("POST", "/api/book", self.book_payload(current["state"], "rail"))[0], 200)
        status, replay = self.request("POST", "/api/book", payload)
        self.assertEqual(status, 200)
        self.assertIsNone(replay["booking"])  # Same phase after reset still is not the old trip.
        self.assertEqual(replay["state"]["gross_extra"], 2140)

    def test_one_tap_wins_over_older_cloud_turn_without_overwriting_booking(self):
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        _, shown = self.request("GET", "/api/state")
        started, release = threading.Event(), threading.Event()
        older = []

        def interpret(*_args):
            started.set()
            release.wait(timeout=2)
            return {"actions": [{"type": "stage_plan", "plan_id": "coach"}],
                    "focus": "answer", "reply": ""}

        with patch.object(ai_bridge, "enabled", return_value=True), patch.object(ai_bridge, "interpret", side_effect=interpret):
            thread = threading.Thread(target=lambda: older.append(self.request("POST", "/api/conversation", {"text": "I want the coach"})))
            thread.start()
            self.assertTrue(started.wait(timeout=2))
            status, booked = self.request("POST", "/api/book", self.book_payload(shown["state"], "rail"))
            release.set()
            thread.join(timeout=3)
        self.assertEqual(status, 200)
        self.assertEqual(booked["state"]["phase"], "travel_secured")
        self.assertIn("older request", older[0][1]["reply"])
        self.assertIsNone(older[0][1]["pending"])
        self.assertEqual(older[0][1]["state"]["chosen"][0]["id"], "rail")

    def test_out_of_order_model_response_cannot_consume_newer_review(self):
        self.request("POST", "/api/conversation", {"text": "Flight delayed"})
        started = threading.Event()
        release = threading.Event()
        older = []

        def interpret(text, _state, _memory):
            if "coach" in text.lower():
                started.set()
                release.wait(timeout=2)
                return {"actions": [{"type": "stage_plan", "plan_id": "coach"}], "focus": "answer", "reply": ""}
            return {"actions": [{"type": "review_plan", "plan_id": "rail"}], "focus": "answer", "reply": ""}

        with patch.object(ai_bridge, "enabled", return_value=True), patch.object(ai_bridge, "interpret", side_effect=interpret):
            thread = threading.Thread(target=lambda: older.append(self.request("POST", "/api/conversation", {"text": "Book the coach"})))
            thread.start()
            self.assertTrue(started.wait(timeout=2))
            _, newer = self.request("POST", "/api/conversation", {"text": "Tell me about the later train"})
            release.set()
            thread.join(timeout=3)
        self.assertEqual(newer["state"]["phase"], "flight_alert")
        self.assertEqual(older[0][0], 200)
        self.assertIn("older request", older[0][1]["reply"])
        self.assertIsNone(older[0][1]["pending"])

    def test_private_source_not_served_and_bad_payloads_rejected(self):
        for path in ("/server.py", "/ai_bridge.py", "/booking_apps.py", "/test_engine.py", "/.env"):
            status, _ = self.request("GET", path)
            self.assertEqual(status, 404, path)
        status, bad = self.request("POST", "/api/conversation", {"text": "x" * 501})
        self.assertEqual(status, 400)
        self.assertIn("short request", bad["error"])
        status, bad = self.request("POST", "/api/conversation", b"not-json")
        self.assertEqual(status, 400)
        self.assertEqual(bad["error"], "Invalid JSON body.")


if __name__ == "__main__":
    unittest.main()
