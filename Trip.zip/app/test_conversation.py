"""Conversational safety and state-transition checks; no provider calls."""
import unittest
from unittest.mock import patch

from conversation import (
    ConversationMemory, explicit_plan_consent, local_decision, present_context,
    redact, respond, validate_decision,
)
from engine import TripEngine


class ConversationTests(unittest.TestCase):
    def setUp(self):
        self.engine = TripEngine()
        self.memory = ConversationMemory()

    def ask(self, text, decision=None, mode="guided"):
        return respond(self.engine, self.memory, text, decision, mode)

    def test_natural_flight_delay_and_budget_in_one_turn(self):
        answer = self.ask("The plane is delayed and I can only spend ₹1,500. Can I make it to Mum?")
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertEqual(answer["state"]["preferences"]["max_extra"], 1500)
        self.assertEqual([p["id"] for p in answer["state"]["plans"]], ["coach"])
        self.assertIn("coach", answer["reply"].lower())
        self.assertEqual(answer["state"]["gross_extra"], 0)

    def test_hypothetical_does_not_change_trip(self):
        answer = self.ask("What if the flight is delayed?")
        self.assertEqual(answer["state"]["phase"], "ready")
        self.assertIn("If the sample flight", answer["reply"])
        malicious = {"actions": [{"type": "flight_delay"}], "focus": "options", "reply": ""}
        answer = self.ask("What if the flight is delayed?", malicious, "ai")
        self.assertEqual(answer["state"]["phase"], "ready")

    def test_road_and_accessibility_are_hard_constraints(self):
        self.ask("My flight's running late")
        answer = self.ask("I do not want overnight road travel")
        self.assertTrue(answer["state"]["preferences"]["avoid_overnight_road"])
        self.assertEqual([p["id"] for p in answer["state"]["plans"]], ["rail"])
        answer = self.ask("I need a wheelchair-accessible route")
        self.assertTrue(answer["state"]["preferences"]["step_free_only"])
        self.assertEqual([p["id"] for p in answer["state"]["plans"]], ["rail"])

    def test_two_step_approval_with_natural_plan_specific_words(self):
        self.ask("Our flight is delayed")
        staged = self.ask("I think the coach works. Can you book that one?")
        self.assertEqual(staged["pending"]["plan_id"], "coach")
        self.assertEqual(staged["state"]["gross_extra"], 0)
        self.assertIn("Shall I virtually book", staged["reply"])
        refused = self.ask("yes")
        self.assertEqual(refused["state"]["phase"], "flight_alert")
        self.assertIn("Just to be safe", refused["reply"])
        approved = self.ask("Yes, confirm the coach please")
        self.assertEqual(approved["state"]["phase"], "travel_secured")
        self.assertEqual(approved["state"]["gross_extra"], 1150)
        self.assertIsNone(approved["pending"])
        self.assertIn("No real ticket", approved["reply"])

    def test_single_clear_voice_or_typed_answer_books_all_virtual_parts(self):
        self.ask("Flight is late")
        result = self.ask("Yes, book the later train for 2140")
        self.assertEqual(result["state"]["phase"], "travel_secured")
        self.assertIsNone(result["pending"])
        receipt = result["booking"]
        self.assertTrue(receipt["simulation"])
        self.assertFalse(receipt["live_booking"])
        self.assertEqual([s["price"] for s in receipt["steps"]], [690, 1450])
        self.assertEqual([s["app"] for s in receipt["steps"]], ["Virtual Rail App", "Virtual Stay App"])
        self.assertEqual(result["state"]["gross_extra"], 2140)
        self.assertIn("No real ticket", result["reply"])

    def test_competing_options_and_price_are_not_approval(self):
        self.ask("Flight is late")
        coach = self.engine.snapshot()["plans"][0]
        for words in ("Yes, book the coach and the later train", "Yes, book coach for ₹2,140",
                      "Should I book the coach?", "Yes, book the coach, but only if it's step free"):
            self.assertFalse(explicit_plan_consent(words, coach), words)
        rail = self.engine.snapshot()["plans"][1]
        self.assertFalse(explicit_plan_consent("Yes, book the train", rail))  # Old and later trains coexist.
        answer = self.ask("Yes, book coach and train")
        self.assertEqual(answer["state"]["gross_extra"], 0)
        self.assertIsNone(answer["booking"])

    def test_confirmation_of_wrong_plan_is_rejected(self):
        self.ask("Flight is late")
        self.ask("I want the coach")
        result = self.ask("Yes, confirm the train")
        self.assertEqual(result["state"]["phase"], "flight_alert")
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertFalse(explicit_plan_consent("no, confirm the coach", self.engine.snapshot()["plans"][0]))

    def test_new_access_condition_cannot_be_hidden_inside_approval(self):
        self.ask("Flight delayed")
        self.ask("I want the coach")
        result = self.ask("Yes, confirm the coach, but I need step-free access")
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertEqual(result["state"]["phase"], "flight_alert")
        self.assertIsNone(result["pending"])
        self.assertIn("another condition", result["reply"])
        updated = self.ask("I need a wheelchair-accessible route")
        self.assertEqual([p["id"] for p in updated["state"]["plans"]], ["rail"])

    def test_switching_plans_stages_new_quote_not_old_confirmation(self):
        self.ask("Flight is delayed")
        self.ask("I want the coach")
        result = self.ask("Actually book the later train instead")
        self.assertEqual(result["pending"]["plan_id"], "rail")
        result = self.ask("Yes, confirm the later train")
        self.assertEqual(result["state"]["chosen"][0]["id"], "rail")

    def test_stale_quote_is_never_confirmed(self):
        self.ask("Flight is delayed")
        self.ask("I want the coach")
        self.engine.set_preferences({"max_extra": 2600})
        result = self.ask("Yes, confirm the coach")
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertIn("expired", result["reply"])

    def test_sold_out_offer_fails_without_payment_or_cancellation(self):
        self.ask("Flight is delayed")
        self.ask("I want the coach")
        self.ask("Test sold out")
        result = self.ask("Yes, confirm the coach")
        self.assertEqual(result["state"]["phase"], "flight_alert")
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertEqual([p["id"] for p in result["state"]["plans"]], ["rail"])
        self.assertIn("No replacement was booked", result["reply"])

    def test_second_disruption_keeps_confirmed_transport(self):
        self.ask("My flight's delayed")
        self.ask("I want the later train")
        self.ask("Yes, confirm the later train")
        result = self.ask("The hotel has cancelled. What now?")
        self.assertEqual(result["state"]["phase"], "hotel_alert")
        self.assertEqual(result["state"]["journey"][1]["status"], "Demo confirmed")
        self.assertEqual(result["state"]["refund_confirmed"], 1450)
        self.ask("I'd choose Royal Fern")
        result = self.ask("Yes, confirm Royal Fern for 1090")
        self.assertEqual(result["state"]["phase"], "complete")
        self.assertEqual(result["state"]["gross_extra"], 1780)
        self.assertTrue(result["download"] is False)

    def test_pausing_does_not_spend_and_clears_pending(self):
        self.ask("Flight delayed")
        self.ask("I want the coach")
        answer = self.ask("Honestly it's not worth spending more; I'll stay in Bengaluru")
        self.assertEqual(answer["state"]["gross_extra"], 0)
        self.assertIsNone(answer["pending"])
        self.assertIn("tomorrow", answer["reply"])
        self.assertIn("Cubbon Park", answer["reply"])

    def test_every_visible_starter_has_a_grounded_conversational_answer(self):
        ready = self.ask("What do you know about my trip?")
        self.assertIn("The Tamarind House", ready["reply"])
        self.ask("Flight delayed")
        self.ask("I want the later train")
        self.ask("Yes, confirm the later train")
        confirmed = self.ask("What's already confirmed?")
        self.assertIn("Sandalwood Stay", confirmed["reply"])
        self.ask("My hotel just cancelled")
        preserved = self.ask("Can I keep my train?")
        self.assertIn("still confirmed", preserved["reply"])
        self.ask("I'd choose Royal Fern")
        self.ask("Yes, confirm Royal Fern")
        final = self.ask("Read my final plan")
        self.assertIn("Royal Fern House", final["reply"])
        self.assertIn("₹1,780", final["reply"])

    def test_metro_and_road_are_compared_before_rejecting_old_train(self):
        self.ask("Flight delayed")
        answer = self.ask("Could I take the metro and make my original train?")
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertIn("21:10", answer["reply"])
        self.assertIn("21:35", answer["reply"])
        self.assertIn("Neither is a live route", answer["reply"])

    def test_restart_is_separately_confirmed(self):
        self.ask("Flight delayed")
        staged = self.ask("Let's start over")
        self.assertEqual(staged["pending"]["kind"], "reset")
        self.assertEqual(staged["state"]["phase"], "flight_alert")
        result = self.ask("Yes, restart the demo")
        self.assertEqual(result["state"]["phase"], "ready")
        self.assertIsNone(result["pending"])

    def test_model_cannot_execute_unknown_action_or_invent_plan(self):
        self.ask("Flight delayed")
        state = self.engine.snapshot()
        malicious = {"actions": [{"type": "charge_card", "amount": 9999}, {"type": "stage_plan", "plan_id": "fake"}],
                     "focus": "status", "reply": "I have booked your real train."}
        result = self.ask("How is my trip?", malicious, "ai")
        self.assertIsNone(result["pending"])
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertNotIn("real train", result["reply"])
        self.assertEqual(validate_decision(malicious, state, self.memory)["actions"], [])

    def test_model_cannot_claim_simulated_confirmation_in_free_form_reply(self):
        self.ask("Flight delayed")
        malicious = {"actions": [], "focus": "answer", "reply": "Your coach ticket is confirmed for ₹1,150 and I sent the email."}
        answer = self.ask("Can you explain what happened?", malicious, "ai")
        self.assertNotIn("ticket is confirmed", answer["reply"])
        self.assertEqual(answer["state"]["phase"], "flight_alert")
        self.assertEqual(answer["state"]["gross_extra"], 0)

    def test_model_cannot_approve_without_explicit_plan_reference(self):
        self.ask("Flight delayed")
        self.ask("I want the coach")
        decision = {"actions": [{"type": "confirm_plan"}], "focus": "answer", "reply": "Done!"}
        result = self.ask("yes", decision, "ai")
        self.assertEqual(result["state"]["gross_extra"], 0)
        self.assertIn("Just to be safe", result["reply"])

    def test_sensitive_sequences_redacted_from_memory(self):
        text = "My email is ananya@example.com and Aadhaar 1234 5678 9012; PAN ABCDE1234F"
        self.ask(text)
        self.assertNotIn("ananya@example.com", str(self.memory.history))
        self.assertNotIn("1234 5678 9012", str(self.memory.history))
        self.assertNotIn("ABCDE1234F", str(self.memory.history))
        self.assertIn("[number redacted]", redact(text))
        self.assertIn("[PAN redacted]", redact(text))

    def test_contextual_pronoun_refers_to_last_plan(self):
        self.ask("Flight delayed")
        self.ask("Tell me about the train")
        decision = local_decision("Okay, I want that one", self.engine.snapshot(), self.memory)
        self.assertEqual(decision["actions"], [{"type": "stage_plan", "plan_id": "rail"}])
        self.assertEqual(present_context(self.engine, self.memory)["pending"], None)

    def test_contractions_and_status_question_work_in_guided_mode(self):
        result = self.ask("My flight's running late, and I don't want an overnight coach")
        self.assertEqual(result["state"]["phase"], "flight_alert")
        self.assertTrue(result["state"]["preferences"]["avoid_overnight_road"])
        self.assertEqual([p["id"] for p in result["state"]["plans"]], ["rail"])
        answer = self.ask("What's confirmed?")
        self.assertIn("No replacement is confirmed", answer["reply"])

    def test_consent_rejects_questions_generic_words_and_competing_plan(self):
        self.ask("Flight delayed")
        self.ask("I want the coach")
        coach = self.engine.snapshot()["plans"][0]
        for utterance in ("confirm demo booking", "Should I confirm the coach?", "Maybe book the coach",
                          "Yes, confirm the train instead of the coach", "No, confirm the coach"):
            self.assertFalse(explicit_plan_consent(utterance, coach), utterance)
        result = self.ask("I don't want to confirm the coach")
        self.assertIsNone(result["pending"])
        self.assertEqual(result["state"]["gross_extra"], 0)

    def test_cloud_model_cannot_invent_budget_or_choose_wrong_quote(self):
        self.ask("Flight delayed")
        dishonest = {"actions": [{"type": "set_budget", "amount": 8000}], "focus": "answer", "reply": "Now you can spend more."}
        result = self.ask("What's confirmed?", dishonest, "ai")
        self.assertEqual(result["state"]["preferences"]["max_extra"], 2500)
        self.assertEqual(result["mode"], "guided")
        dishonest = {"actions": [{"type": "stage_plan", "plan_id": "coach"}], "focus": "answer", "reply": ""}
        result = self.ask("Please choose the later train", dishonest, "ai")
        self.assertEqual(result["pending"]["plan_id"], "rail")
        self.assertEqual(result["mode"], "guided")
        self.assertEqual(result["state"]["gross_extra"], 0)

    def test_new_budget_precedes_a_compound_model_plan_choice(self):
        self.ask("Flight delayed")
        decision = {"actions": [{"type": "set_budget", "amount": 500},
                                {"type": "stage_plan", "plan_id": "coach"}], "focus": "options", "reply": ""}
        result = self.ask("I can spend at most 500; book the coach", decision, "ai")
        self.assertEqual(result["state"]["preferences"]["max_extra"], 500)
        self.assertIsNone(result["pending"])
        self.assertTrue(result["state"]["no_feasible"])
        self.assertEqual(result["state"]["gross_extra"], 0)

    def test_model_cannot_mutate_hypothetical_or_cancel_request(self):
        self.ask("Flight delayed")
        model = {"actions": [{"type": "hotel_cancelled"}], "focus": "options", "reply": ""}
        result = self.ask("Can you cancel my hotel booking?", model, "ai")
        self.assertEqual(result["state"]["phase"], "flight_alert")
        self.assertIn("can't cancel", result["reply"])
        proposed = {"actions": [{"type": "set_budget", "amount": 8000}], "focus": "options", "reply": ""}
        result = self.ask("What if I could spend ₹8,000?", proposed, "ai")
        self.assertEqual(result["state"]["preferences"]["max_extra"], 2500)

    def test_reset_response_clears_old_conversation_on_client(self):
        self.ask("Flight delayed")
        self.ask("Restart the demo")
        result = self.ask("Yes, restart the demo")
        self.assertTrue(result["restarted"])
        self.assertEqual(result["state"]["phase"], "ready")
        self.assertEqual(len(self.memory.history), 1)


if __name__ == "__main__":
    unittest.main()
